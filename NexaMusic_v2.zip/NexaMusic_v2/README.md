# Nexa Music v2

Nexa Music é um player Android com identidade própria, criado por J. Pastore e com a experiência Nexa AI integrada.

## O que entrou na v2

- Player real baseado em Android Media3 / ExoPlayer.
- Reprodução em segundo plano por `MediaSessionService`.
- Controles de mídia na notificação e integração com a tela bloqueada do Android.
- Mini-player e player expandido com progresso, avançar, voltar, aleatório e repetição.
- Favoritos persistentes no aparelho.
- Histórico de reprodução persistente.
- Criação de playlists locais.
- Adição e remoção de músicas em playlists.
- Busca por música, artista e contexto.
- Nexa AI Beta para montar filas por intenção usando o catálogo atual.
- Interface grafite, roxo elétrico e azul neon.
- Créditos mantidos no final do menu Perfil.

## Catálogo

A v2 mantém as faixas originais Nexa Sessions incluídas no projeto. A arquitetura do player já está pronta para receber um catálogo autorizado/licenciado em uma etapa posterior.

## Compilação no GitHub

O workflow `.github/workflows/android.yml` gera o APK de debug via GitHub Actions com Java 17, Android API 35 e Gradle 8.9.

## Créditos

Nexa Music  
Criado por J. Pastore  
Powered by Nexa AI  
© 2026 • Versão 2.0.0
