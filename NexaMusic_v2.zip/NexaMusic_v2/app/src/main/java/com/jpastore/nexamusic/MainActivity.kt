package com.jpastore.nexamusic

import android.Manifest
import android.content.ComponentName
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.delay
import java.util.Locale
import kotlin.math.max

private val Bg = Color(0xFF0B0D12)
private val Surface1 = Color(0xFF151922)
private val Surface2 = Color(0xFF1B202C)
private val Purple = Color(0xFF7C3AED)
private val Blue = Color(0xFF00C2FF)
private val Magenta = Color(0xFFE946FF)
private val TextPrimary = Color(0xFFF5F7FA)
private val TextSecondary = Color(0xFF9CA3AF)
private val Success = Color(0xFF49D49D)

private data class NavDestination(val label: String, val icon: ImageVector)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2001)
        }

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Purple,
                    secondary = Blue,
                    tertiary = Magenta,
                    background = Bg,
                    surface = Surface1,
                    onPrimary = Color.White,
                    onBackground = TextPrimary,
                    onSurface = TextPrimary
                )
            ) {
                NexaMusicApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NexaMusicApp() {
    val context = LocalContext.current
    val store = remember { LibraryStore(context.applicationContext) }
    val liked = remember { mutableStateListOf<Int>().apply { addAll(store.getLiked()) } }
    var history by remember { mutableStateOf(store.getHistory()) }
    var playlists by remember { mutableStateOf(store.getPlaylists()) }

    var selectedTab by remember { mutableIntStateOf(0) }
    var controller by remember { mutableStateOf<MediaController?>(null) }
    var currentTrack by remember { mutableStateOf<Track?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var shuffleEnabled by remember { mutableStateOf(false) }
    var repeatMode by remember { mutableIntStateOf(Player.REPEAT_MODE_OFF) }
    var showPlayer by remember { mutableStateOf(false) }
    var showPlaylistDialog by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener(
            {
                runCatching { future.get() }.onSuccess { mediaController ->
                    controller = mediaController
                    currentTrack = Catalog.byMediaId(mediaController.currentMediaItem?.mediaId)
                    isPlaying = mediaController.isPlaying
                    shuffleEnabled = mediaController.shuffleModeEnabled
                    repeatMode = mediaController.repeatMode
                }
            },
            ContextCompat.getMainExecutor(context)
        )
        onDispose {
            MediaController.releaseFuture(future)
            controller = null
        }
    }

    DisposableEffect(controller) {
        val c = controller
        if (c == null) {
            onDispose { }
        } else {
            val listener = object : Player.Listener {
                override fun onIsPlayingChanged(playing: Boolean) {
                    isPlaying = playing
                }

                override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                    currentTrack = Catalog.byMediaId(mediaItem?.mediaId)
                    currentTrack?.let { history = store.addHistory(it.id) }
                }

                override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
                    shuffleEnabled = shuffleModeEnabled
                }

                override fun onRepeatModeChanged(mode: Int) {
                    repeatMode = mode
                }
            }
            c.addListener(listener)
            onDispose { c.removeListener(listener) }
        }
    }

    fun playQueue(queue: List<Track>, selected: Track) {
        val c = controller ?: return
        if (queue.isEmpty()) return
        val index = queue.indexOfFirst { it.id == selected.id }.coerceAtLeast(0)
        c.setMediaItems(queue.map { it.toMediaItem(context) }, index, 0L)
        c.prepare()
        c.play()
        currentTrack = selected
        history = store.addHistory(selected.id)
    }

    fun playTrack(track: Track) = playQueue(Catalog.tracks, track)

    fun togglePlay() {
        val c = controller ?: return
        if (c.mediaItemCount == 0) {
            playTrack(Catalog.tracks.first())
        } else if (c.isPlaying) {
            c.pause()
        } else {
            c.play()
        }
    }

    fun next() {
        controller?.let { c ->
            if (c.hasNextMediaItem()) c.seekToNextMediaItem() else c.seekToDefaultPosition(0)
            c.play()
        }
    }

    fun previous() {
        controller?.let { c ->
            if (c.currentPosition > 4_000) c.seekTo(0)
            else if (c.hasPreviousMediaItem()) c.seekToPreviousMediaItem()
            else c.seekToDefaultPosition(0)
            c.play()
        }
    }

    fun toggleLiked(track: Track) {
        if (liked.contains(track.id)) liked.remove(track.id) else liked.add(track.id)
        store.setLiked(liked)
    }

    fun createPlaylist(name: String) {
        playlists = store.createPlaylist(name)
    }

    fun createPlaylistAndAdd(name: String, track: Track) {
        val clean = name.trim()
        if (clean.isBlank()) return
        store.createPlaylist(clean)
        playlists = store.addToPlaylist(clean, track.id)
    }

    fun addToPlaylist(name: String, track: Track) {
        playlists = store.addToPlaylist(name, track.id)
    }

    fun removeFromPlaylist(name: String, track: Track) {
        playlists = store.removeFromPlaylist(name, track.id)
    }

    fun deletePlaylist(name: String) {
        playlists = store.deletePlaylist(name)
    }

    val destinations = listOf(
        NavDestination("Início", Icons.Rounded.Home),
        NavDestination("Explorar", Icons.Rounded.Explore),
        NavDestination("Nexa AI", Icons.Rounded.AutoAwesome),
        NavDestination("Biblioteca", Icons.Rounded.LibraryMusic),
        NavDestination("Perfil", Icons.Rounded.Person)
    )

    Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                Column(
                    modifier = Modifier
                        .background(Bg)
                        .navigationBarsPadding()
                ) {
                    currentTrack?.let { track ->
                        MiniPlayer(
                            track = track,
                            isPlaying = isPlaying,
                            onOpen = { showPlayer = true },
                            onToggle = ::togglePlay,
                            onNext = ::next
                        )
                    }
                    NavigationBar(containerColor = Color(0xFF10141B)) {
                        destinations.forEachIndexed { index, item ->
                            val selected = selectedTab == index
                            NavigationBarItem(
                                selected = selected,
                                onClick = { selectedTab = index },
                                icon = { Icon(item.icon, item.label) },
                                label = { Text(item.label, fontSize = 10.sp, maxLines = 1) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Blue,
                                    selectedTextColor = TextPrimary,
                                    indicatorColor = Purple.copy(alpha = 0.22f),
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary
                                )
                            )
                        }
                    }
                }
            }
        ) { padding ->
            when (selectedTab) {
                0 -> HomeScreen(
                    modifier = Modifier.padding(padding),
                    onPlay = ::playTrack,
                    onOpenAI = { selectedTab = 2 }
                )
                1 -> ExploreScreen(
                    modifier = Modifier.padding(padding),
                    onPlay = ::playTrack
                )
                2 -> AiScreen(
                    modifier = Modifier.padding(padding),
                    onPlayQueue = { queue -> if (queue.isNotEmpty()) playQueue(queue, queue.first()) }
                )
                3 -> LibraryScreen(
                    modifier = Modifier.padding(padding),
                    likedIds = liked,
                    historyIds = history,
                    playlists = playlists,
                    onPlay = ::playTrack,
                    onCreatePlaylist = ::createPlaylist,
                    onRemoveFromPlaylist = ::removeFromPlaylist,
                    onDeletePlaylist = ::deletePlaylist
                )
                else -> ProfileScreen(modifier = Modifier.padding(padding))
            }
        }
    }

    if (showPlayer && currentTrack != null) {
        ModalBottomSheet(
            onDismissRequest = { showPlayer = false },
            containerColor = Surface1,
            contentColor = TextPrimary
        ) {
            FullPlayer(
                modifier = Modifier.fillMaxHeight(0.93f),
                track = currentTrack!!,
                controller = controller,
                isPlaying = isPlaying,
                isLiked = liked.contains(currentTrack!!.id),
                shuffleEnabled = shuffleEnabled,
                repeatMode = repeatMode,
                onToggle = ::togglePlay,
                onNext = ::next,
                onPrevious = ::previous,
                onLike = { toggleLiked(currentTrack!!) },
                onPlaylist = { showPlaylistDialog = true },
                onShuffle = {
                    controller?.let {
                        it.shuffleModeEnabled = !it.shuffleModeEnabled
                        shuffleEnabled = it.shuffleModeEnabled
                    }
                },
                onRepeat = {
                    controller?.let {
                        val nextMode = when (it.repeatMode) {
                            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                            else -> Player.REPEAT_MODE_OFF
                        }
                        it.repeatMode = nextMode
                        repeatMode = nextMode
                    }
                }
            )
        }
    }

    if (showPlaylistDialog && currentTrack != null) {
        AddToPlaylistDialog(
            track = currentTrack!!,
            playlistNames = playlists.keys.toList(),
            onDismiss = { showPlaylistDialog = false },
            onAdd = { name ->
                addToPlaylist(name, currentTrack!!)
                showPlaylistDialog = false
            },
            onCreateAndAdd = { name ->
                createPlaylistAndAdd(name, currentTrack!!)
                showPlaylistDialog = false
            }
        )
    }
}

@Composable
private fun HomeScreen(
    modifier: Modifier = Modifier,
    onPlay: (Track) -> Unit,
    onOpenAI: () -> Unit
) {
    LazyColumn(
        modifier = modifier.fillMaxSize().background(Bg),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(22.dp)
    ) {
        item {
            Column {
                Text("NEXA MUSIC", color = Blue, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text("O que vamos ouvir?", color = TextPrimary, fontWeight = FontWeight.ExtraBold, fontSize = 29.sp)
                Text("Música que entende o seu momento.", color = TextSecondary, fontSize = 14.sp)
            }
        }
        item { AiHeroCard(onOpenAI) }
        item { SectionHeader("Feito para você", "Seleções da Nexa") }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                items(Catalog.tracks) { track -> AlbumCard(track, onPlay = { onPlay(track) }) }
            }
        }
        item { SectionHeader("Nexa Sessions", "Faixas disponíveis agora") }
        items(Catalog.tracks) { track -> TrackRow(track, onClick = { onPlay(track) }) }
        item { Spacer(Modifier.height(8.dp)) }
    }
}

@Composable
private fun AiHeroCard(onOpenAI: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onOpenAI),
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Brush.linearGradient(listOf(Purple, Color(0xFF194DBE), Blue)))
                .padding(22.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.AutoAwesome, null, tint = Color.White)
                    Spacer(Modifier.width(8.dp))
                    Text("Nexa AI", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                }
                Text(
                    "Diga o seu momento. A Nexa organiza a fila para você.",
                    color = Color.White.copy(alpha = 0.92f),
                    fontSize = 15.sp
                )
                Button(
                    onClick = onOpenAI,
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF372071))
                ) {
                    Icon(Icons.Rounded.AutoAwesome, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Criar com IA", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun AlbumCard(track: Track, onPlay: () -> Unit) {
    Column(modifier = Modifier.width(148.dp).clickable(onClick = onPlay)) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .clip(RoundedCornerShape(22.dp))
                .background(trackBrush(track)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Rounded.MusicNote, null, tint = Color.White, modifier = Modifier.size(52.dp))
            FilledIconButton(
                onClick = onPlay,
                modifier = Modifier.align(Alignment.BottomEnd).padding(10.dp),
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color.Black.copy(alpha = 0.72f))
            ) {
                Icon(Icons.Rounded.PlayArrow, "Tocar", tint = Color.White)
            }
        }
        Spacer(Modifier.height(9.dp))
        Text(track.title, color = TextPrimary, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(track.mood, color = TextSecondary, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun ExploreScreen(modifier: Modifier = Modifier, onPlay: (Track) -> Unit) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(query) {
        if (query.isBlank()) Catalog.tracks else Catalog.tracks.filter {
            (it.title + " " + it.artist + " " + it.mood)
                .lowercase(Locale.getDefault())
                .contains(query.lowercase(Locale.getDefault()))
        }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("Explorar", color = TextPrimary, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
            Text("Busque por música, artista ou momento.", color = TextSecondary)
        }
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                leadingIcon = { Icon(Icons.Rounded.Search, null) },
                placeholder = { Text("Ex.: treino, foco, Nexa Sessions") },
                shape = RoundedCornerShape(18.dp)
            )
        }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(listOf("Treino", "Foco", "Relaxar", "Eletrônico")) { label ->
                    AssistChip(
                        onClick = { query = label },
                        label = { Text(label) },
                        leadingIcon = { Icon(Icons.Rounded.Headphones, null, Modifier.size(18.dp)) },
                        colors = AssistChipDefaults.assistChipColors(
                            containerColor = Surface2,
                            labelColor = TextPrimary,
                            leadingIconContentColor = Blue
                        )
                    )
                }
            }
        }
        item { SectionHeader("Resultados", "${filtered.size} faixa(s)") }
        items(filtered) { track -> TrackRow(track, onClick = { onPlay(track) }) }
        if (filtered.isEmpty()) {
            item { Text("Nenhuma faixa encontrada no catálogo atual.", color = TextSecondary) }
        }
    }
}

@Composable
private fun AiScreen(modifier: Modifier = Modifier, onPlayQueue: (List<Track>) -> Unit) {
    var prompt by remember { mutableStateOf("") }
    var generated by remember { mutableStateOf<List<Track>>(emptyList()) }
    var explanation by remember { mutableStateOf("Conte para a Nexa o que você quer ouvir.") }

    fun generate() {
        val p = prompt.lowercase(Locale.getDefault())
        generated = when {
            listOf("treino", "academia", "energia", "correr", "corrida").any(p::contains) ->
                listOf(Catalog.tracks[1], Catalog.tracks[0], Catalog.tracks[2])
            listOf("relax", "calma", "dormir", "tranquilo", "descansar").any(p::contains) ->
                listOf(Catalog.tracks[2], Catalog.tracks[0], Catalog.tracks[1])
            listOf("foco", "estudar", "trabalho", "concentrar").any(p::contains) ->
                listOf(Catalog.tracks[0], Catalog.tracks[2], Catalog.tracks[1])
            else -> Catalog.tracks.shuffled()
        }
        explanation = when {
            p.contains("treino") || p.contains("academia") -> "Comecei com mais energia e deixei o final mais leve."
            p.contains("relax") || p.contains("calma") -> "Organizei uma sequência mais suave para desacelerar."
            p.contains("foco") || p.contains("estudar") -> "Priorizei faixas de foco e baixa distração."
            else -> "Montei uma sequência variada usando o catálogo disponível."
        }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier.size(50.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Purple, Blue))),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Rounded.AutoAwesome, null, tint = Color.White) }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("Nexa AI", color = TextPrimary, fontSize = 29.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Sua DJ inteligente • Beta", color = Blue, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        item {
            Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Surface1)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text(explanation, color = TextSecondary)
                    OutlinedTextField(
                        value = prompt,
                        onValueChange = { prompt = it },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2,
                        placeholder = { Text("Ex.: Quero músicas animadas para treinar") },
                        trailingIcon = { Icon(Icons.Rounded.Mic, "Voz em evolução", tint = TextSecondary) },
                        shape = RoundedCornerShape(18.dp)
                    )
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(listOf("Treino", "Foco", "Relaxar", "Me surpreenda")) { chip ->
                            AssistChip(
                                onClick = { prompt = chip },
                                label = { Text(chip) },
                                colors = AssistChipDefaults.assistChipColors(containerColor = Surface2, labelColor = TextPrimary)
                            )
                        }
                    }
                    Button(
                        onClick = { generate() },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Purple)
                    ) {
                        Icon(Icons.Rounded.AutoAwesome, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Gerar seleção", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        if (generated.isNotEmpty()) {
            item { SectionHeader("A Nexa escolheu", "Fila pronta para tocar") }
            items(generated) { track -> TrackRow(track, onClick = { onPlayQueue(generated.dropWhile { it.id != track.id } + generated.takeWhile { it.id != track.id }) }) }
            item {
                Button(
                    onClick = { onPlayQueue(generated) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Blue, contentColor = Color(0xFF001018))
                ) {
                    Icon(Icons.Rounded.PlayArrow, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Tocar seleção completa", fontWeight = FontWeight.Bold)
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Purple.copy(alpha = 0.12f))) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Info, null, tint = Blue)
                    Spacer(Modifier.width(10.dp))
                    Text(
                        "A Nexa AI Beta já organiza o catálogo do app por contexto. A conexão com o modelo de IA online entra na próxima camada do projeto.",
                        color = TextSecondary,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun LibraryScreen(
    modifier: Modifier = Modifier,
    likedIds: List<Int>,
    historyIds: List<Int>,
    playlists: Map<String, List<Int>>,
    onPlay: (Track) -> Unit,
    onCreatePlaylist: (String) -> Unit,
    onRemoveFromPlaylist: (String, Track) -> Unit,
    onDeletePlaylist: (String) -> Unit
) {
    val likedTracks = Catalog.tracks.filter { likedIds.contains(it.id) }
    val historyTracks = historyIds.mapNotNull(Catalog::byId)
    var newPlaylistName by remember { mutableStateOf("") }
    var showCreateDialog by remember { mutableStateOf(false) }
    var expandedPlaylist by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("Sua biblioteca", color = TextPrimary, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
            Text("Curtidas, histórico e playlists salvos neste aparelho.", color = TextSecondary)
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                LibraryShortcut("Curtidas", "${likedTracks.size} músicas", Icons.Rounded.Favorite, Modifier.weight(1f))
                LibraryShortcut("Histórico", "${historyTracks.size} recentes", Icons.Rounded.History, Modifier.weight(1f))
            }
        }
        item {
            Button(
                onClick = { showCreateDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = Purple)
            ) {
                Icon(Icons.Rounded.Add, null)
                Spacer(Modifier.width(8.dp))
                Text("Nova playlist", fontWeight = FontWeight.Bold)
            }
        }
        item { SectionHeader("Músicas curtidas", if (likedTracks.isEmpty()) "Use o coração no player" else "Seus favoritos") }
        if (likedTracks.isEmpty()) {
            item { EmptyLibraryText("Abra o player de uma música e toque no coração para salvar.") }
        } else {
            items(likedTracks) { TrackRow(it, onClick = { onPlay(it) }) }
        }

        item { SectionHeader("Ouvidas recentemente", if (historyTracks.isEmpty()) "Seu histórico aparecerá aqui" else "Últimas reproduções") }
        if (historyTracks.isEmpty()) {
            item { EmptyLibraryText("As músicas que você tocar serão registradas automaticamente.") }
        } else {
            items(historyTracks.take(8)) { TrackRow(it, onClick = { onPlay(it) }) }
        }

        item { SectionHeader("Suas playlists", if (playlists.isEmpty()) "Crie a primeira acima" else "${playlists.size} playlist(s)") }
        if (playlists.isEmpty()) {
            item { EmptyLibraryText("Crie playlists e adicione músicas pelo player expandido.") }
        } else {
            items(playlists.entries.toList()) { entry ->
                PlaylistCard(
                    name = entry.key,
                    count = entry.value.size,
                    expanded = expandedPlaylist == entry.key,
                    onOpen = { expandedPlaylist = if (expandedPlaylist == entry.key) null else entry.key },
                    onDelete = { onDeletePlaylist(entry.key); if (expandedPlaylist == entry.key) expandedPlaylist = null }
                )
                if (expandedPlaylist == entry.key) {
                    val playlistTracks = entry.value.mapNotNull(Catalog::byId)
                    if (playlistTracks.isEmpty()) {
                        EmptyLibraryText("Playlist vazia. Adicione uma música pelo player.")
                    } else {
                        playlistTracks.forEach { track ->
                            PlaylistTrackRow(
                                track = track,
                                onPlay = { onPlay(track) },
                                onRemove = { onRemoveFromPlaylist(entry.key, track) }
                            )
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(12.dp)) }
    }

    if (showCreateDialog) {
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text("Nova playlist") },
            text = {
                OutlinedTextField(
                    value = newPlaylistName,
                    onValueChange = { newPlaylistName = it },
                    singleLine = true,
                    label = { Text("Nome") }
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (newPlaylistName.isNotBlank()) {
                            onCreatePlaylist(newPlaylistName)
                            expandedPlaylist = newPlaylistName.trim()
                            newPlaylistName = ""
                            showCreateDialog = false
                        }
                    }
                ) { Text("Criar") }
            },
            dismissButton = { TextButton(onClick = { showCreateDialog = false }) { Text("Cancelar") } }
        )
    }
}

@Composable
private fun PlaylistCard(name: String, count: Int, expanded: Boolean, onOpen: () -> Unit, onDelete: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Surface1), shape = RoundedCornerShape(18.dp)) {
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onOpen).padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(48.dp).clip(RoundedCornerShape(13.dp)).background(Brush.linearGradient(listOf(Purple, Blue))),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Rounded.QueueMusic, null, tint = Color.White) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(name, color = TextPrimary, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("$count música(s)", color = TextSecondary, fontSize = 12.sp)
            }
            IconButton(onClick = onDelete) { Icon(Icons.Rounded.Delete, "Excluir playlist", tint = TextSecondary) }
            Icon(Icons.Rounded.ChevronRight, null, tint = if (expanded) Blue else TextSecondary)
        }
    }
}

@Composable
private fun PlaylistTrackRow(track: Track, onPlay: () -> Unit, onRemove: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(start = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.weight(1f)) { TrackRow(track, onClick = onPlay) }
        IconButton(onClick = onRemove) { Icon(Icons.Rounded.Delete, "Remover", tint = TextSecondary) }
    }
}

@Composable
private fun EmptyLibraryText(text: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Surface1.copy(alpha = 0.72f)), shape = RoundedCornerShape(16.dp)) {
        Text(text, color = TextSecondary, fontSize = 13.sp, modifier = Modifier.fillMaxWidth().padding(14.dp))
    }
}

@Composable
private fun LibraryShortcut(title: String, subtitle: String, icon: ImageVector, modifier: Modifier = Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = Surface1), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Icon(icon, null, tint = Blue, modifier = Modifier.size(30.dp))
            Text(title, color = TextPrimary, fontWeight = FontWeight.Bold)
            Text(subtitle, color = TextSecondary, fontSize = 12.sp)
        }
    }
}

@Composable
private fun ProfileScreen(modifier: Modifier = Modifier) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("Perfil", color = TextPrimary, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
            Text("Preferências e informações do Nexa Music.", color = TextSecondary)
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Surface1), shape = RoundedCornerShape(22.dp)) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(54.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Purple, Blue))),
                        contentAlignment = Alignment.Center
                    ) { Text("JP", color = Color.White, fontWeight = FontWeight.ExtraBold) }
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text("Nexa Music", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("Biblioteca local ativa", color = Success, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
        item { MenuRow(Icons.Rounded.Settings, "Configurações", "Reprodução e aparência") }
        item { MenuRow(Icons.Rounded.Headphones, "Reprodução em segundo plano", "Ativa com controles do sistema") }
        item { MenuRow(Icons.Rounded.LibraryMusic, "Conteúdo offline", "Preparado para catálogo autorizado") }
        item { MenuRow(Icons.Rounded.Info, "Privacidade e termos", "Área preparada para publicação") }
        item { Spacer(Modifier.height(20.dp)) }
        item {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                Text("Sobre o Nexa Music", color = TextSecondary, fontWeight = FontWeight.SemiBold)
                Text("Nexa Music", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("Criado por J. Pastore", color = Blue, fontWeight = FontWeight.Bold)
                Text("Powered by Nexa AI", color = Purple)
                Text("© 2026 • Versão 2.0.0", color = TextSecondary, fontSize = 12.sp)
            }
        }
        item { Spacer(Modifier.height(12.dp)) }
    }
}

@Composable
private fun MenuRow(icon: ImageVector, title: String, subtitle: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Surface1), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Blue)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = TextSecondary, fontSize = 12.sp)
            }
            Icon(Icons.Rounded.ChevronRight, null, tint = TextSecondary)
        }
    }
}

@Composable
private fun TrackRow(track: Track, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier.size(58.dp).clip(RoundedCornerShape(15.dp)).background(trackBrush(track)),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Rounded.MusicNote, null, tint = Color.White) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(track.title, color = TextPrimary, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${track.artist} • ${track.mood}", color = TextSecondary, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Icon(Icons.Rounded.PlayArrow, "Tocar", tint = Blue)
    }
}

@Composable
private fun MiniPlayer(track: Track, isPlaying: Boolean, onOpen: () -> Unit, onToggle: () -> Unit, onNext: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().background(Surface2).clickable(onClick = onOpen).padding(horizontal = 18.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(48.dp).clip(RoundedCornerShape(13.dp)).background(trackBrush(track)),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Rounded.MusicNote, null, tint = Color.White) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(track.title, color = TextPrimary, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(track.artist, color = TextSecondary, fontSize = 12.sp, maxLines = 1)
        }
        IconButton(onClick = onToggle) {
            Icon(if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, if (isPlaying) "Pausar" else "Tocar", tint = Color.White)
        }
        IconButton(onClick = onNext) { Icon(Icons.Rounded.SkipNext, "Próxima", tint = Color.White) }
    }
}

@Composable
private fun FullPlayer(
    modifier: Modifier = Modifier,
    track: Track,
    controller: MediaController?,
    isPlaying: Boolean,
    isLiked: Boolean,
    shuffleEnabled: Boolean,
    repeatMode: Int,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onLike: () -> Unit,
    onPlaylist: () -> Unit,
    onShuffle: () -> Unit,
    onRepeat: () -> Unit
) {
    var position by remember(track.id) { mutableLongStateOf(0L) }
    var duration by remember(track.id) { mutableLongStateOf(1L) }

    LaunchedEffect(controller, track.id, isPlaying) {
        while (true) {
            val c = controller
            if (c != null) {
                position = c.currentPosition.coerceAtLeast(0L)
                duration = max(c.duration.takeIf { it > 0 } ?: 1L, 1L)
            }
            delay(500)
        }
    }

    Column(
        modifier = modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Text("TOCANDO AGORA", color = TextSecondary, fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.4.sp)
        Box(
            modifier = Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(30.dp)).background(trackBrush(track)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Rounded.MusicNote, null, tint = Color.White.copy(alpha = 0.95f), modifier = Modifier.size(92.dp))
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(track.title, color = TextPrimary, fontWeight = FontWeight.ExtraBold, fontSize = 25.sp)
                Text(track.artist, color = TextSecondary, fontSize = 15.sp)
            }
            IconButton(onClick = onPlaylist) { Icon(Icons.Rounded.PlaylistAdd, "Adicionar à playlist", tint = Blue) }
            IconButton(onClick = onLike) {
                Icon(if (isLiked) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, "Favoritar", tint = if (isLiked) Magenta else TextSecondary)
            }
        }
        Column {
            Slider(
                value = position.coerceAtMost(duration).toFloat(),
                onValueChange = { controller?.seekTo(it.toLong()) },
                valueRange = 0f..duration.toFloat().coerceAtLeast(1f),
                modifier = Modifier.fillMaxWidth()
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(formatTime(position), color = TextSecondary, fontSize = 11.sp)
                Text(formatTime(duration), color = TextSecondary, fontSize = 11.sp)
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onShuffle) {
                Icon(Icons.Rounded.Shuffle, "Aleatório", tint = if (shuffleEnabled) Blue else TextSecondary)
            }
            IconButton(onClick = onPrevious) { Icon(Icons.Rounded.SkipPrevious, "Anterior", tint = Color.White, modifier = Modifier.size(34.dp)) }
            FilledIconButton(
                onClick = onToggle,
                modifier = Modifier.size(72.dp),
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color.White, contentColor = Color(0xFF14141A))
            ) {
                Icon(if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, if (isPlaying) "Pausar" else "Tocar", modifier = Modifier.size(38.dp))
            }
            IconButton(onClick = onNext) { Icon(Icons.Rounded.SkipNext, "Próxima", tint = Color.White, modifier = Modifier.size(34.dp)) }
            IconButton(onClick = onRepeat) {
                Icon(
                    if (repeatMode == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                    "Repetir",
                    tint = if (repeatMode == Player.REPEAT_MODE_OFF) TextSecondary else Blue
                )
            }
        }
        Text("Controles disponíveis também na notificação e na tela bloqueada.", color = TextSecondary, fontSize = 12.sp)
        Spacer(Modifier.height(18.dp))
    }
}

@Composable
private fun AddToPlaylistDialog(
    track: Track,
    playlistNames: List<String>,
    onDismiss: () -> Unit,
    onAdd: (String) -> Unit,
    onCreateAndAdd: (String) -> Unit
) {
    var newName by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Adicionar à playlist") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(track.title, color = TextSecondary)
                playlistNames.forEach { name ->
                    OutlinedButton(onClick = { onAdd(name) }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Rounded.QueueMusic, null)
                        Spacer(Modifier.width(8.dp))
                        Text(name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                if (playlistNames.isEmpty()) {
                    Text("Você ainda não tem playlists.", color = TextSecondary, fontSize = 13.sp)
                }
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    label = { Text("Nova playlist") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = { if (newName.isNotBlank()) onCreateAndAdd(newName) },
                    enabled = newName.isNotBlank(),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Rounded.Add, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Criar e adicionar")
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Fechar") } }
    )
}

@Composable
private fun SectionHeader(title: String, subtitle: String) {
    Column {
        Text(title, color = TextPrimary, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
        Text(subtitle, color = TextSecondary, fontSize = 13.sp)
    }
}

private fun trackBrush(track: Track) = Brush.linearGradient(listOf(Color(track.startColor), Color(track.endColor)))

private fun formatTime(milliseconds: Long): String {
    if (milliseconds <= 0) return "0:00"
    val totalSeconds = milliseconds / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%d:%02d".format(minutes, seconds)
}
