package com.jpastore.nexamusic

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

internal class LibraryStore(context: Context) {
    private val prefs = context.getSharedPreferences("nexa_music_library", Context.MODE_PRIVATE)

    fun getLiked(): Set<Int> = prefs.getStringSet(KEY_LIKED, emptySet())
        .orEmpty()
        .mapNotNull { it.toIntOrNull() }
        .toSet()

    fun setLiked(ids: Collection<Int>) {
        prefs.edit().putStringSet(KEY_LIKED, ids.map(Int::toString).toSet()).apply()
    }

    fun getHistory(): List<Int> = prefs.getString(KEY_HISTORY, "")
        .orEmpty()
        .split(',')
        .mapNotNull { it.toIntOrNull() }
        .distinct()
        .take(MAX_HISTORY)

    fun addHistory(trackId: Int): List<Int> {
        val updated = (listOf(trackId) + getHistory().filterNot { it == trackId }).take(MAX_HISTORY)
        prefs.edit().putString(KEY_HISTORY, updated.joinToString(",")).apply()
        return updated
    }

    fun getPlaylists(): Map<String, List<Int>> {
        val source = prefs.getString(KEY_PLAYLISTS, null) ?: return emptyMap()
        return runCatching {
            val root = JSONObject(source)
            buildMap {
                val keys = root.keys()
                while (keys.hasNext()) {
                    val name = keys.next()
                    val arr = root.optJSONArray(name) ?: JSONArray()
                    val ids = buildList {
                        for (i in 0 until arr.length()) {
                            arr.optInt(i, -1).takeIf { it > 0 }?.let(::add)
                        }
                    }.distinct()
                    put(name, ids)
                }
            }
        }.getOrDefault(emptyMap())
    }

    fun createPlaylist(name: String): Map<String, List<Int>> {
        val clean = name.trim().take(40)
        if (clean.isBlank()) return getPlaylists()
        val updated = getPlaylists().toMutableMap()
        if (!updated.containsKey(clean)) updated[clean] = emptyList()
        savePlaylists(updated)
        return updated
    }

    fun addToPlaylist(name: String, trackId: Int): Map<String, List<Int>> {
        val updated = getPlaylists().toMutableMap()
        val items = updated[name].orEmpty()
        updated[name] = (items + trackId).distinct()
        savePlaylists(updated)
        return updated
    }

    fun removeFromPlaylist(name: String, trackId: Int): Map<String, List<Int>> {
        val updated = getPlaylists().toMutableMap()
        updated[name] = updated[name].orEmpty().filterNot { it == trackId }
        savePlaylists(updated)
        return updated
    }

    fun deletePlaylist(name: String): Map<String, List<Int>> {
        val updated = getPlaylists().toMutableMap()
        updated.remove(name)
        savePlaylists(updated)
        return updated
    }

    private fun savePlaylists(playlists: Map<String, List<Int>>) {
        val root = JSONObject()
        playlists.forEach { (name, ids) ->
            val arr = JSONArray()
            ids.forEach(arr::put)
            root.put(name, arr)
        }
        prefs.edit().putString(KEY_PLAYLISTS, root.toString()).apply()
    }

    companion object {
        private const val KEY_LIKED = "liked"
        private const val KEY_HISTORY = "history"
        private const val KEY_PLAYLISTS = "playlists"
        private const val MAX_HISTORY = 30
    }
}
