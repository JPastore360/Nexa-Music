package com.jpastore.nexamusic

import android.content.Context
import android.net.Uri
import androidx.annotation.RawRes
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata

internal data class Track(
    val id: Int,
    val title: String,
    val artist: String,
    val mood: String,
    @RawRes val rawRes: Int,
    val startColor: Long,
    val endColor: Long
)

internal object Catalog {
    val tracks = listOf(
        Track(
            id = 1,
            title = "Neon Horizon",
            artist = "Nexa Sessions",
            mood = "foco • eletrônico",
            rawRes = R.raw.nexa_neon,
            startColor = 0xFF7C3AED,
            endColor = 0xFF00C2FF
        ),
        Track(
            id = 2,
            title = "Pulse Drive",
            artist = "Nexa Sessions",
            mood = "treino • energia",
            rawRes = R.raw.nexa_pulse,
            startColor = 0xFFE946FF,
            endColor = 0xFF7C3AED
        ),
        Track(
            id = 3,
            title = "Quiet Orbit",
            artist = "Nexa Sessions",
            mood = "relaxar • ambiente",
            rawRes = R.raw.nexa_orbit,
            startColor = 0xFF00C2FF,
            endColor = 0xFF213A78
        )
    )

    fun byId(id: Int): Track? = tracks.firstOrNull { it.id == id }
    fun byMediaId(mediaId: String?): Track? = mediaId?.toIntOrNull()?.let(::byId)
}

internal fun Track.toMediaItem(context: Context): MediaItem {
    val uri = "android.resource://${context.packageName}/$rawRes"
    return MediaItem.Builder()
        .setMediaId(id.toString())
        .setUri(uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artist)
                .setAlbumTitle("Nexa Sessions")
                .setArtworkUri(Uri.parse("android.resource://${context.packageName}/${R.drawable.nexa_music_icon}"))
                .build()
        )
        .build()
}
