-- Nexa Music v5: execute uma vez no SQL Editor do Supabase.
-- A tabela guarda somente a biblioteca do próprio usuário autenticado.

create table if not exists public.nexa_library (
  user_id uuid primary key references auth.users(id) on delete cascade,
  liked jsonb not null default '[]'::jsonb,
  history jsonb not null default '[]'::jsonb,
  playlists jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.nexa_library enable row level security;

drop policy if exists "nexa_library_select_own" on public.nexa_library;
create policy "nexa_library_select_own"
on public.nexa_library for select
to authenticated
using (auth.uid() = user_id);

drop policy if exists "nexa_library_insert_own" on public.nexa_library;
create policy "nexa_library_insert_own"
on public.nexa_library for insert
to authenticated
with check (auth.uid() = user_id);

drop policy if exists "nexa_library_update_own" on public.nexa_library;
create policy "nexa_library_update_own"
on public.nexa_library for update
to authenticated
using (auth.uid() = user_id)
with check (auth.uid() = user_id);
