# Nexa Music v5

Versão 5.0.0 do Nexa Music.

## O que mudou

- Nova tela de login/cadastro com e-mail + senha ou telefone + senha.
- Modo visitante para testar sem configurar backend.
- Integração preparada com Supabase Auth usando `SUPABASE_URL` e `SUPABASE_ANON_KEY`.
- Biblioteca em nuvem (favoritos, histórico e playlists) quando a tabela `nexa_library` estiver criada com o arquivo `supabase_schema.sql`.
- Busca híbrida: Audius + Jamendo (quando `JAMENDO_CLIENT_ID` estiver configurado) + catálogo amplo usado apenas para reconhecer melhor artista/título e fazer novas tentativas nas fontes de streaming integral.
- Reprodução continua usando Media3, inclusive em segundo plano e tela bloqueada.
- Perfil exibe conta conectada ou modo visitante e permite sair.
- Créditos continuam no final do Perfil.

## GitHub Secrets opcionais

Em **Settings > Secrets and variables > Actions**, adicione:

- `SUPABASE_URL`
- `SUPABASE_ANON_KEY`
- `JAMENDO_CLIENT_ID`

Sem esses secrets o APK ainda compila e funciona em modo visitante com Audius. O Jamendo e o login online ficam desativados até as chaves serem configuradas.

## Supabase

Crie um projeto gratuito no Supabase e execute `supabase_schema.sql` no SQL Editor para ativar a sincronização da biblioteca. Habilite e-mail/senha no Auth. Para telefone, habilite Phone Auth e um provedor de SMS/WhatsApp; esse provedor pode ter custo próprio.

## Observação sobre catálogo

A Nexa Music prioriza fontes que entregam streams completos autorizados. A busca de metadados ampla não transforma automaticamente músicas comerciais em streams gratuitos. Quando uma versão integral não existir nas fontes conectadas, ela não é reproduzida como se estivesse disponível.

Criado por J. Pastore • Powered by Nexa AI
