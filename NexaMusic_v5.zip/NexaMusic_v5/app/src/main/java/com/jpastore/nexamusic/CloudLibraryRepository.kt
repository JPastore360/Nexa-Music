package com.jpastore.nexamusic

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

internal data class LibrarySnapshot(
    val liked: List<Track>,
    val history: List<Track>,
    val playlists: Map<String, List<Track>>
) {
    fun isEmpty(): Boolean = liked.isEmpty() && history.isEmpty() && playlists.values.all { it.isEmpty() }
}

internal object CloudLibraryRepository {
    suspend fun pull(session: AuthSession): LibrarySnapshot? = withContext(Dispatchers.IO) {
        if (session.isGuest || session.accessToken.isBlank() || !AuthRepository.configured) return@withContext null
        try {
            val path = "/rest/v1/nexa_library?user_id=eq.${session.userId}&select=liked,history,playlists&limit=1"
            val text = request("GET", path, session, null, null)
            val array = JSONArray(text)
            val row = array.optJSONObject(0) ?: return@withContext LibrarySnapshot(emptyList(), emptyList(), emptyMap())
            LibrarySnapshot(
                liked = parseTracks(row.optJSONArray("liked") ?: JSONArray()),
                history = parseTracks(row.optJSONArray("history") ?: JSONArray()),
                playlists = parsePlaylists(row.optJSONObject("playlists") ?: JSONObject())
            )
        } catch (_: Exception) {
            null
        }
    }

    suspend fun push(
        session: AuthSession,
        liked: List<Track>,
        history: List<Track>,
        playlists: Map<String, List<Track>>
    ): Boolean = withContext(Dispatchers.IO) {
        if (session.isGuest || session.accessToken.isBlank() || !AuthRepository.configured) return@withContext false
        try {
            val row = JSONObject().apply {
                put("user_id", session.userId)
                put("liked", tracksArray(liked))
                put("history", tracksArray(history.take(40)))
                put("playlists", playlistsObject(playlists))
            }
            request(
                method = "POST",
                path = "/rest/v1/nexa_library?on_conflict=user_id",
                session = session,
                body = row.toString(),
                prefer = "resolution=merge-duplicates,return=minimal"
            )
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun request(
        method: String,
        path: String,
        session: AuthSession,
        body: String?,
        prefer: String?
    ): String {
        val base = BuildConfig.SUPABASE_URL.trimEnd('/')
        val connection = URL(base + path).openConnection() as HttpURLConnection
        connection.requestMethod = method
        connection.connectTimeout = 15_000
        connection.readTimeout = 20_000
        connection.setRequestProperty("Accept", "application/json")
        connection.setRequestProperty("Content-Type", "application/json")
        connection.setRequestProperty("apikey", BuildConfig.SUPABASE_ANON_KEY)
        connection.setRequestProperty("Authorization", "Bearer ${session.accessToken}")
        if (!prefer.isNullOrBlank()) connection.setRequestProperty("Prefer", prefer)
        if (body != null) {
            connection.doOutput = true
            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        }

        return try {
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw IllegalStateException(text.ifBlank { "HTTP $code" })
            text
        } finally {
            connection.disconnect()
        }
    }

    private fun tracksArray(tracks: List<Track>): JSONArray = JSONArray().apply {
        tracks.forEach { put(it.toJson()) }
    }

    private fun playlistsObject(playlists: Map<String, List<Track>>): JSONObject = JSONObject().apply {
        playlists.forEach { (name, tracks) -> put(name, tracksArray(tracks)) }
    }

    private fun parseTracks(array: JSONArray): List<Track> {
        val out = mutableListOf<Track>()
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            trackFromJson(item)?.let { out += it }
        }
        return out.distinctBy { it.id }
    }

    private fun parsePlaylists(root: JSONObject): Map<String, List<Track>> {
        val output = linkedMapOf<String, List<Track>>()
        val keys = root.keys()
        while (keys.hasNext()) {
            val name = keys.next()
            output[name] = parseTracks(root.optJSONArray(name) ?: JSONArray())
        }
        return output
    }
}
