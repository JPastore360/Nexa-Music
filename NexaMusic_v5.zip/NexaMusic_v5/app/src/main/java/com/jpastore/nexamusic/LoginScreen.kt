package com.jpastore.nexamusic

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Email
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Phone
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

private val LoginBg = Color(0xFF0B0D12)
private val LoginPanel = Color(0xFF151922)
private val LoginPurple = Color(0xFF7C3AED)
private val LoginBlue = Color(0xFF00C2FF)
private val LoginText = Color(0xFFF5F7FA)
private val LoginMuted = Color(0xFF9CA3AF)

@Composable
internal fun LoginScreen(onAuthenticated: (AuthSession) -> Unit) {
    val scope = rememberCoroutineScope()
    var phoneMode by remember { mutableStateOf(false) }
    var createMode by remember { mutableStateOf(false) }
    var identifier by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }

    fun submit() {
        val id = identifier.trim()
        if (id.isBlank() || password.length < 6 || loading) return
        scope.launch {
            loading = true
            message = ""
            val result = try {
                if (createMode) AuthRepository.signUp(id, password, phoneMode)
                else AuthRepository.signIn(id, password, phoneMode)
            } catch (_: Exception) {
                AuthResponse(message = "Falha ao conectar. Verifique a internet e tente novamente.")
            }
            loading = false
            result.session?.let(onAuthenticated)
            if (result.session == null) message = result.message
        }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = LoginBg) {
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier.size(74.dp).clip(CircleShape)
                    .background(Brush.linearGradient(listOf(LoginPurple, LoginBlue))),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.Headphones, contentDescription = null, tint = Color.White, modifier = Modifier.size(38.dp))
            }
            Spacer(Modifier.height(18.dp))
            Text("NEXA MUSIC", color = LoginBlue, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Text(
                if (createMode) "Crie sua conta" else "Bem-vindo de volta",
                color = LoginText,
                fontSize = 31.sp,
                fontWeight = FontWeight.ExtraBold
            )
            Text(
                "Sua música, playlists e preferências em um só lugar.",
                color = LoginMuted,
                modifier = Modifier.padding(top = 6.dp, bottom = 22.dp)
            )

            Card(colors = CardDefaults.cardColors(containerColor = LoginPanel), shape = RoundedCornerShape(26.dp)) {
                Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        val emailSelected = !phoneMode
                        OutlinedButton(
                            onClick = { phoneMode = false; identifier = ""; message = "" },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = if (emailSelected) LoginBlue else LoginMuted)
                        ) {
                            Icon(Icons.Rounded.Email, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text("E-mail")
                        }
                        OutlinedButton(
                            onClick = { phoneMode = true; identifier = ""; message = "" },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = if (phoneMode) LoginBlue else LoginMuted)
                        ) {
                            Icon(Icons.Rounded.Phone, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text("Telefone")
                        }
                    }

                    OutlinedTextField(
                        value = identifier,
                        onValueChange = { identifier = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        leadingIcon = { Icon(if (phoneMode) Icons.Rounded.Phone else Icons.Rounded.Email, contentDescription = null) },
                        label = { Text(if (phoneMode) "Telefone com DDI" else "E-mail") },
                        placeholder = { Text(if (phoneMode) "+55 17 99999-9999" else "voce@email.com") },
                        shape = RoundedCornerShape(17.dp)
                    )

                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        leadingIcon = { Icon(Icons.Rounded.Lock, contentDescription = null) },
                        label = { Text("Senha") },
                        visualTransformation = PasswordVisualTransformation(),
                        shape = RoundedCornerShape(17.dp)
                    )

                    Button(
                        onClick = { submit() },
                        enabled = identifier.isNotBlank() && password.length >= 6 && !loading,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (loading) CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                        else Text(if (createMode) "Criar conta" else "Entrar", fontWeight = FontWeight.Bold)
                    }

                    if (message.isNotBlank()) {
                        Text(message, color = LoginMuted, fontSize = 13.sp)
                    }

                    if (!AuthRepository.configured) {
                        Text(
                            "O login online está pronto no projeto, mas precisa das chaves gratuitas do Supabase no GitHub. Você pode testar o app como visitante agora.",
                            color = LoginMuted,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            Spacer(Modifier.height(14.dp))
            TextButton(onClick = { createMode = !createMode; message = "" }, modifier = Modifier.fillMaxWidth()) {
                Text(if (createMode) "Já tenho uma conta • Entrar" else "Ainda não tenho conta • Criar conta")
            }
            OutlinedButton(
                onClick = { onAuthenticated(AuthSession("guest", "Visitante", "", "", true)) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Continuar como visitante")
            }
            Spacer(Modifier.height(18.dp))
            Text(
                "Nexa Music • Criado por J. Pastore",
                color = LoginMuted,
                fontSize = 12.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
        }
    }
}
