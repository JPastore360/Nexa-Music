package com.jpastore.nexamusic

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class AuthSession(
    val userId: String,
    val label: String,
    val accessToken: String,
    val refreshToken: String = "",
    val isGuest: Boolean = false
)

data class AuthResponse(
    val session: AuthSession? = null,
    val message: String = ""
)

internal object AuthRepository {
    val configured: Boolean
        get() = BuildConfig.SUPABASE_URL.isNotBlank() && BuildConfig.SUPABASE_ANON_KEY.isNotBlank()

    suspend fun signIn(identifier: String, password: String, usePhone: Boolean): AuthResponse =
        withContext(Dispatchers.IO) {
            if (!configured) return@withContext AuthResponse(message = "Login online ainda não foi configurado neste APK.")
            val body = JSONObject().apply {
                put(if (usePhone) "phone" else "email", identifier.trim())
                put("password", password)
            }
            val json = post("/auth/v1/token?grant_type=password", body)
            parseSession(json, identifier)
        }

    suspend fun signUp(identifier: String, password: String, usePhone: Boolean): AuthResponse =
        withContext(Dispatchers.IO) {
            if (!configured) return@withContext AuthResponse(message = "Cadastro online ainda não foi configurado neste APK.")
            val body = JSONObject().apply {
                put(if (usePhone) "phone" else "email", identifier.trim())
                put("password", password)
                if (usePhone) {
                    put("channel", "sms")
                }
            }
            val json = post("/auth/v1/signup", body)
            val parsed = parseSession(json, identifier)
            if (parsed.session != null) parsed
            else AuthResponse(message = parsed.message.ifBlank {
                if (usePhone) "Cadastro solicitado. Verifique o telefone para concluir a confirmação."
                else "Conta criada. Verifique seu e-mail para concluir a confirmação."
            })
        }

    private fun parseSession(json: JSONObject, fallbackLabel: String): AuthResponse {
        if (json.has("error") || json.has("error_description") || json.has("msg")) {
            val msg = listOf(
                json.optString("msg"),
                json.optString("error_description"),
                json.optString("error")
            ).firstOrNull { it.isNotBlank() }.orEmpty()
            return AuthResponse(message = msg.ifBlank { "Não foi possível autenticar." })
        }

        val access = json.optString("access_token")
        val refresh = json.optString("refresh_token")
        val user = json.optJSONObject("user")
        val userId = user?.optString("id").orEmpty()
        val label = user?.optString("email").orEmpty()
            .ifBlank { user?.optString("phone").orEmpty() }
            .ifBlank { fallbackLabel }

        return if (access.isNotBlank() && userId.isNotBlank()) {
            AuthResponse(AuthSession(userId, label, access, refresh, false), "Conectado")
        } else {
            AuthResponse(message = "Cadastro recebido. Confirme sua conta para entrar.")
        }
    }

    private fun post(path: String, body: JSONObject): JSONObject {
        val base = BuildConfig.SUPABASE_URL.trimEnd('/')
        val connection = URL(base + path).openConnection() as HttpURLConnection
        connection.requestMethod = "POST"
        connection.connectTimeout = 15_000
        connection.readTimeout = 20_000
        connection.doOutput = true
        connection.setRequestProperty("Content-Type", "application/json")
        connection.setRequestProperty("Accept", "application/json")
        connection.setRequestProperty("apikey", BuildConfig.SUPABASE_ANON_KEY)
        connection.setRequestProperty("Authorization", "Bearer ${BuildConfig.SUPABASE_ANON_KEY}")
        connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

        return try {
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (text.isBlank()) JSONObject().put("error", "HTTP $code")
            else JSONObject(text)
        } finally {
            connection.disconnect()
        }
    }
}
