package com.jpastore.nexamusic

import android.content.Context

internal class AuthStore(context: Context) {
    private val prefs = context.getSharedPreferences("nexa_music_auth_v5", Context.MODE_PRIVATE)

    fun load(): AuthSession? {
        val userId = prefs.getString("userId", null) ?: return null
        val label = prefs.getString("label", "Usuário").orEmpty()
        val access = prefs.getString("access", "").orEmpty()
        val refresh = prefs.getString("refresh", "").orEmpty()
        val guest = prefs.getBoolean("guest", false)
        return AuthSession(userId, label, access, refresh, guest)
    }

    fun save(session: AuthSession) {
        prefs.edit()
            .putString("userId", session.userId)
            .putString("label", session.label)
            .putString("access", session.accessToken)
            .putString("refresh", session.refreshToken)
            .putBoolean("guest", session.isGuest)
            .apply()
    }

    fun clear() = prefs.edit().clear().apply()
}
