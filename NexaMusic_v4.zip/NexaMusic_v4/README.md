# Nexa Music v4

Aplicativo Android criado por **J. Pastore**, com interface premium, busca musical, biblioteca, playlists, Nexa AI e reprodução em segundo plano.

## O que muda na v4

A fonte principal de áudio passa a ser o **Audius / Open Audio Protocol**. O app busca faixas públicas e usa o endpoint oficial de streaming para reprodução integral das faixas que estiverem liberadas pelo catálogo.

- Busca online no Audius
- Home com músicas em alta e coleções/artistas
- Streaming integral de faixas públicas e não bloqueadas
- Player Media3 / ExoPlayer
- Reprodução em segundo plano e tela bloqueada
- Favoritos, histórico e playlists locais
- Nexa AI para montar seleções
- Perfil com configurações funcionais

## Limitação importante

O Audius não possui necessariamente o mesmo catálogo comercial do Spotify, Apple Music ou YouTube Music. Músicas ausentes no Audius não podem ser reproduzidas pela Nexa Music usando esta fonte. Faixas com stream protegido/gated são ignoradas pela v4.

## Créditos

Nexa Music  
Criado por J. Pastore  
Powered by Nexa AI  
© 2026 • Versão 4.0.0
