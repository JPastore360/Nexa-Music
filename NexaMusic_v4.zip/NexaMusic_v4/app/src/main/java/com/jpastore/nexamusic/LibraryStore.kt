package com.jpastore.nexamusic

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

internal class LibraryStore(context: Context) {
    private val prefs = context.getSharedPreferences("nexa_music_library_v31", Context.MODE_PRIVATE)

    fun getLiked(): List<Track> = readTracks(KEY_LIKED)

    fun toggleLiked(track: Track): List<Track> {
        val items = getLiked().toMutableList()
        val index = items.indexOfFirst { it.id == track.id }
        if (index >= 0) items.removeAt(index) else items.add(0, track)
        writeTracks(KEY_LIKED, items)
        return items
    }

    fun getHistory(): List<Track> = readTracks(KEY_HISTORY)

    fun addHistory(track: Track): List<Track> {
        val items = mutableListOf<Track>()
        items += track
        items += getHistory().filterNot { it.id == track.id }
        val limited = items.take(40)
        writeTracks(KEY_HISTORY, limited)
        return limited
    }

    fun getPlaylists(): Map<String, List<Track>> {
        val raw = prefs.getString(KEY_PLAYLISTS, null) ?: return emptyMap()
        return try {
            val root = JSONObject(raw)
            val output = linkedMapOf<String, List<Track>>()
            val keys = root.keys()
            while (keys.hasNext()) {
                val name = keys.next()
                output[name] = parseTrackArray(root.optJSONArray(name) ?: JSONArray())
            }
            output
        } catch (_: Exception) {
            emptyMap()
        }
    }

    fun createPlaylist(name: String): Map<String, List<Track>> {
        val clean = name.trim().take(40)
        if (clean.isBlank()) return getPlaylists()
        val updated = getPlaylists().toMutableMap()
        if (!updated.containsKey(clean)) updated[clean] = emptyList()
        savePlaylists(updated)
        return updated
    }

    fun addToPlaylist(name: String, track: Track): Map<String, List<Track>> {
        val updated = getPlaylists().toMutableMap()
        val current = updated[name].orEmpty().toMutableList()
        if (current.none { it.id == track.id }) current.add(track)
        updated[name] = current
        savePlaylists(updated)
        return updated
    }

    fun removeFromPlaylist(name: String, track: Track): Map<String, List<Track>> {
        val updated = getPlaylists().toMutableMap()
        updated[name] = updated[name].orEmpty().filterNot { it.id == track.id }
        savePlaylists(updated)
        return updated
    }

    fun deletePlaylist(name: String): Map<String, List<Track>> {
        val updated = getPlaylists().toMutableMap()
        updated.remove(name)
        savePlaylists(updated)
        return updated
    }

    private fun readTracks(key: String): List<Track> {
        val raw = prefs.getString(key, null) ?: return emptyList()
        return try {
            parseTrackArray(JSONArray(raw))
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun writeTracks(key: String, tracks: List<Track>) {
        val array = JSONArray()
        tracks.forEach { array.put(it.toJson()) }
        prefs.edit().putString(key, array.toString()).apply()
    }

    private fun parseTrackArray(array: JSONArray): List<Track> {
        val tracks = mutableListOf<Track>()
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            trackFromJson(item)?.let { tracks += it }
        }
        return tracks.distinctBy { it.id }
    }

    private fun savePlaylists(playlists: Map<String, List<Track>>) {
        val root = JSONObject()
        for ((name, tracks) in playlists) {
            val array = JSONArray()
            tracks.forEach { array.put(it.toJson()) }
            root.put(name, array)
        }
        prefs.edit().putString(KEY_PLAYLISTS, root.toString()).apply()
    }

    companion object {
        private const val KEY_LIKED = "liked"
        private const val KEY_HISTORY = "history"
        private const val KEY_PLAYLISTS = "playlists"
    }
}
