package com.jpastore.nexamusic

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings as AndroidSettings
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.max

private val Bg = Color(0xFF0B0D12)
private val Surface1 = Color(0xFF151922)
private val Surface2 = Color(0xFF1B202C)
private val Purple = Color(0xFF7C3AED)
private val Blue = Color(0xFF00C2FF)
private val Magenta = Color(0xFFE946FF)
private val TextPrimary = Color(0xFFF5F7FA)
private val TextSecondary = Color(0xFF9CA3AF)
private val Success = Color(0xFF49D49D)
private val Danger = Color(0xFFFF6B7A)

private data class NavDestination(val label: String, val icon: ImageVector)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2001)
        }

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Purple,
                    secondary = Blue,
                    tertiary = Magenta,
                    background = Bg,
                    surface = Surface1,
                    onPrimary = Color.White,
                    onBackground = TextPrimary,
                    onSurface = TextPrimary
                )
            ) {
                NexaMusicApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NexaMusicApp() {
    val context = LocalContext.current
    val store = remember { LibraryStore(context.applicationContext) }

    var liked by remember { mutableStateOf(store.getLiked()) }
    var history by remember { mutableStateOf(store.getHistory()) }
    var playlists by remember { mutableStateOf(store.getPlaylists()) }

    var selectedTab by remember { mutableIntStateOf(0) }
    var controller by remember { mutableStateOf<MediaController?>(null) }
    var currentTrack by remember { mutableStateOf<Track?>(null) }
    var currentQueue by remember { mutableStateOf<List<Track>>(emptyList()) }
    var isPlaying by remember { mutableStateOf(false) }
    var shuffleEnabled by remember { mutableStateOf(false) }
    var repeatMode by remember { mutableIntStateOf(Player.REPEAT_MODE_OFF) }
    var showPlayer by remember { mutableStateOf(false) }
    var showPlaylistDialog by remember { mutableStateOf(false) }
    var albumSeed by remember { mutableStateOf<Track?>(null) }

    DisposableEffect(Unit) {
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener(
            {
                try {
                    val mediaController = future.get()
                    controller = mediaController
                    isPlaying = mediaController.isPlaying
                    shuffleEnabled = mediaController.shuffleModeEnabled
                    repeatMode = mediaController.repeatMode
                } catch (_: Exception) {
                    controller = null
                }
            },
            ContextCompat.getMainExecutor(context)
        )

        onDispose {
            MediaController.releaseFuture(future)
            controller = null
        }
    }

    DisposableEffect(controller, currentQueue) {
        val c = controller
        if (c == null) {
            onDispose { }
        } else {
            val listener = object : Player.Listener {
                override fun onIsPlayingChanged(playing: Boolean) {
                    isPlaying = playing
                }

                override fun onShuffleModeEnabledChanged(enabled: Boolean) {
                    shuffleEnabled = enabled
                }

                override fun onRepeatModeChanged(mode: Int) {
                    repeatMode = mode
                }

                override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                    val mediaId = mediaItem?.mediaId.orEmpty()
                    val track = currentQueue.firstOrNull { it.id == mediaId }
                    if (track != null) {
                        currentTrack = track
                        history = store.addHistory(track)
                    }
                }
            }
            c.addListener(listener)
            onDispose { c.removeListener(listener) }
        }
    }

    fun playQueue(queue: List<Track>, selected: Track) {
        val c = controller ?: return
        if (queue.isEmpty()) return

        val index = queue.indexOfFirst { it.id == selected.id }.let { if (it < 0) 0 else it }
        currentQueue = queue
        c.setMediaItems(queue.map { it.toMediaItem() }, index, 0L)
        c.prepare()
        c.play()
        currentTrack = selected
        history = store.addHistory(selected)
    }

    fun playTrack(track: Track) {
        playQueue(listOf(track), track)
    }

    fun togglePlay() {
        val c = controller ?: return
        if (c.mediaItemCount == 0) return
        if (c.isPlaying) c.pause() else c.play()
    }

    fun next() {
        val c = controller ?: return
        if (c.hasNextMediaItem()) c.seekToNextMediaItem()
        c.play()
    }

    fun previous() {
        val c = controller ?: return
        if (c.currentPosition > 4_000L) {
            c.seekTo(0L)
        } else if (c.hasPreviousMediaItem()) {
            c.seekToPreviousMediaItem()
        }
        c.play()
    }

    val destinations = listOf(
        NavDestination("Início", Icons.Rounded.Home),
        NavDestination("Explorar", Icons.Rounded.Explore),
        NavDestination("Nexa AI", Icons.Rounded.AutoAwesome),
        NavDestination("Biblioteca", Icons.Rounded.LibraryMusic),
        NavDestination("Perfil", Icons.Rounded.Person)
    )

    Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                Column(modifier = Modifier.background(Bg).navigationBarsPadding()) {
                    val playing = currentTrack
                    if (playing != null) {
                        MiniPlayer(
                            track = playing,
                            isPlaying = isPlaying,
                            onOpen = { showPlayer = true },
                            onToggle = { togglePlay() },
                            onNext = { next() }
                        )
                    }

                    NavigationBar(containerColor = Color(0xFF10141B)) {
                        destinations.forEachIndexed { index, item ->
                            NavigationBarItem(
                                selected = selectedTab == index,
                                onClick = { selectedTab = index },
                                icon = { Icon(item.icon, contentDescription = item.label) },
                                label = { Text(item.label, fontSize = 10.sp, maxLines = 1) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Blue,
                                    selectedTextColor = TextPrimary,
                                    indicatorColor = Purple.copy(alpha = 0.22f),
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary
                                )
                            )
                        }
                    }
                }
            }
        ) { padding ->
            when (selectedTab) {
                0 -> HomeScreen(
                    modifier = Modifier.padding(padding),
                    onPlayQueue = { queue, track -> playQueue(queue, track) },
                    onOpenAlbum = { albumSeed = it },
                    onOpenAI = { selectedTab = 2 }
                )
                1 -> ExploreScreen(
                    modifier = Modifier.padding(padding),
                    onPlayQueue = { queue, track -> playQueue(queue, track) },
                    onOpenAlbum = { albumSeed = it }
                )
                2 -> AiScreen(
                    modifier = Modifier.padding(padding),
                    onPlayQueue = { queue ->
                        if (queue.isNotEmpty()) playQueue(queue, queue.first())
                    }
                )
                3 -> LibraryScreen(
                    modifier = Modifier.padding(padding),
                    liked = liked,
                    history = history,
                    playlists = playlists,
                    onPlay = { playTrack(it) },
                    onCreatePlaylist = { name -> playlists = store.createPlaylist(name) },
                    onRemoveFromPlaylist = { name, track -> playlists = store.removeFromPlaylist(name, track) },
                    onDeletePlaylist = { name -> playlists = store.deletePlaylist(name) }
                )
                else -> ProfileScreen(
                    modifier = Modifier.padding(padding),
                    onOpenCatalog = { selectedTab = 1 }
                )
            }
        }
    }

    if (showPlayer) {
        val track = currentTrack
        if (track != null) {
            ModalBottomSheet(
                onDismissRequest = { showPlayer = false },
                containerColor = Surface1,
                contentColor = TextPrimary
            ) {
                FullPlayer(
                    track = track,
                    controller = controller,
                    isPlaying = isPlaying,
                    isLiked = liked.any { it.id == track.id },
                    shuffleEnabled = shuffleEnabled,
                    repeatMode = repeatMode,
                    onToggle = { togglePlay() },
                    onNext = { next() },
                    onPrevious = { previous() },
                    onLike = { liked = store.toggleLiked(track) },
                    onPlaylist = { showPlaylistDialog = true },
                    onShuffle = {
                        val c = controller
                        if (c != null) {
                            c.shuffleModeEnabled = !c.shuffleModeEnabled
                            shuffleEnabled = c.shuffleModeEnabled
                        }
                    },
                    onRepeat = {
                        val c = controller
                        if (c != null) {
                            val mode = when (c.repeatMode) {
                                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                                else -> Player.REPEAT_MODE_OFF
                            }
                            c.repeatMode = mode
                            repeatMode = mode
                        }
                    }
                )
            }
        }
    }

    if (showPlaylistDialog) {
        val track = currentTrack
        if (track != null) {
            AddToPlaylistDialog(
                playlistNames = playlists.keys.toList(),
                onDismiss = { showPlaylistDialog = false },
                onAdd = { name ->
                    playlists = store.addToPlaylist(name, track)
                    showPlaylistDialog = false
                },
                onCreateAndAdd = { name ->
                    playlists = store.createPlaylist(name)
                    playlists = store.addToPlaylist(name.trim(), track)
                    showPlaylistDialog = false
                }
            )
        }
    }

    val seed = albumSeed
    if (seed != null) {
        AlbumDetailSheet(
            seed = seed,
            onDismiss = { albumSeed = null },
            onPlayQueue = { queue, track -> playQueue(queue, track) }
        )
    }
}

@Composable
private fun HomeScreen(
    modifier: Modifier,
    onPlayQueue: (List<Track>, Track) -> Unit,
    onOpenAlbum: (Track) -> Unit,
    onOpenAI: () -> Unit
) {
    var tracks by remember { mutableStateOf<List<Track>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var reloadKey by remember { mutableIntStateOf(0) }

    LaunchedEffect(reloadKey) {
        loading = true
        error = null
        try {
            tracks = CatalogRepository.homeTracks()
            if (tracks.isEmpty()) error = "O catálogo não retornou músicas agora."
        } catch (_: Exception) {
            error = "Não foi possível carregar músicas. Verifique sua internet."
        }
        loading = false
    }

    val albums = remember(tracks) { CatalogRepository.albumsFrom(tracks).take(14) }

    LazyColumn(
        modifier = modifier.fillMaxSize().background(Bg),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        item {
            Column {
                Text("NEXA MUSIC", color = Blue, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text("O que vamos ouvir?", color = TextPrimary, fontWeight = FontWeight.ExtraBold, fontSize = 29.sp)
                Text("Música que entende o seu momento.", color = TextSecondary)
            }
        }

        item { AiHeroCard(onOpenAI = onOpenAI) }

        if (loading) {
            item { LoadingBlock("Carregando músicas do Audius…") }
        } else if (error != null) {
            item { ErrorBlock(text = error ?: "Erro", onRetry = { reloadKey += 1 }) }
        } else {
            item { SectionHeader("Álbuns e artistas para você", "Coleções e artistas disponíveis no catálogo Audius") }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    items(albums, key = { it.collectionId }) { album ->
                        AlbumCard(album = album, onOpen = { onOpenAlbum(album.seedTrack) })
                    }
                }
            }

            item { SectionHeader("Ouça agora", "Faixas públicas com streaming integral") }
            items(tracks.take(18), key = { it.id }) { track ->
                TrackRow(track = track, onClick = { onPlayQueue(tracks, track) })
            }
        }
    }
}

@Composable
private fun AiHeroCard(onOpenAI: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable { onOpenAI() },
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Brush.linearGradient(listOf(Purple, Color(0xFF194DBE), Blue)))
                .padding(22.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.AutoAwesome, contentDescription = null, tint = Color.White)
                    Spacer(Modifier.width(8.dp))
                    Text("Nexa AI", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 19.sp)
                }
                Text("Diga o que quer ouvir e a Nexa monta uma seleção no catálogo.", color = Color.White.copy(alpha = 0.92f))
                Button(
                    onClick = onOpenAI,
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF372071))
                ) {
                    Icon(Icons.Rounded.AutoAwesome, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Criar com IA", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun AlbumCard(album: AlbumSummary, onOpen: () -> Unit) {
    Column(modifier = Modifier.width(150.dp).clickable { onOpen() }) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Surface1)
        ) {
            if (album.artworkUrl.isNotBlank()) {
                AsyncImage(
                    model = album.artworkUrl,
                    contentDescription = "Capa de ${album.title}",
                    modifier = Modifier.fillMaxWidth().aspectRatio(1f)
                )
            } else {
                Box(
                    modifier = Modifier.fillMaxWidth().aspectRatio(1f).background(Surface2),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Rounded.MusicNote, contentDescription = null, tint = Blue, modifier = Modifier.size(48.dp))
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(album.title, color = TextPrimary, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(album.artist, color = TextSecondary, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun ExploreScreen(
    modifier: Modifier,
    onPlayQueue: (List<Track>, Track) -> Unit,
    onOpenAlbum: (Track) -> Unit
) {
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Track>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    fun executeSearch(term: String) {
        val clean = term.trim()
        if (clean.length < 2 || loading) return
        scope.launch {
            loading = true
            error = null
            try {
                results = CatalogRepository.searchSongs(clean, 40)
                if (results.isEmpty()) error = "Nenhum resultado encontrado."
            } catch (_: Exception) {
                error = "Não consegui acessar o catálogo. Tente novamente."
            }
            loading = false
        }
    }

    val albums = remember(results) { CatalogRepository.albumsFrom(results).take(12) }

    LazyColumn(
        modifier = modifier.fillMaxSize().background(Bg),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("Explorar", color = TextPrimary, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
            Text("Busque no catálogo gratuito do Audius.", color = TextSecondary)
        }

        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                placeholder = { Text("Ex.: electronic, hip hop, rock, artista ou música") },
                shape = RoundedCornerShape(18.dp)
            )
        }

        item {
            Button(
                onClick = { executeSearch(query) },
                enabled = query.trim().length >= 2 && !loading,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (loading) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                } else {
                    Icon(Icons.Rounded.Search, contentDescription = null)
                }
                Spacer(Modifier.width(8.dp))
                Text(if (loading) "Buscando…" else "Buscar")
            }
        }

        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                val categories = listOf("Electronic", "Hip-Hop", "Rock", "Pop", "Lo-Fi")
                items(categories) { category ->
                    OutlinedButton(onClick = { query = category; executeSearch(category) }) {
                        Text(category)
                    }
                }
            }
        }

        if (error != null) {
            item { HintBlock(error ?: "") }
        }

        if (results.isNotEmpty()) {
            item { SectionHeader("Álbuns e artistas", "Resultados relacionados no Audius") }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    items(albums, key = { it.collectionId }) { album ->
                        AlbumCard(album = album, onOpen = { onOpenAlbum(album.seedTrack) })
                    }
                }
            }

            item { SectionHeader("Músicas", "${results.size} resultados") }
            items(results, key = { it.id }) { track ->
                TrackRow(track = track, onClick = { onPlayQueue(results, track) })
            }
        } else if (!loading && error == null) {
            item { HintBlock("Digite um artista, música ou álbum e toque em Buscar.") }
        }
    }
}

@Composable
private fun AiScreen(modifier: Modifier, onPlayQueue: (List<Track>) -> Unit) {
    val scope = rememberCoroutineScope()
    var prompt by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var results by remember { mutableStateOf<List<Track>>(emptyList()) }
    var message by remember { mutableStateOf("Descreva seu momento e a Nexa monta uma seleção.") }

    fun translate(text: String): String {
        val value = text.lowercase(Locale.getDefault())
        return when {
            value.contains("academia") || value.contains("treino") -> "workout hits"
            value.contains("relax") || value.contains("calma") -> "acoustic chill"
            value.contains("foco") || value.contains("estudar") || value.contains("trabalho") -> "focus instrumental"
            value.contains("sertanejo") -> "sertanejo brasil"
            value.contains("pagode") -> "pagode brasil"
            value.contains("rock") -> "rock hits"
            value.contains("românt") || value.contains("amor") -> "romantic hits"
            else -> text.trim()
        }
    }

    fun createSelection() {
        if (prompt.trim().length < 2 || loading) return
        scope.launch {
            loading = true
            try {
                results = CatalogRepository.searchSongs(translate(prompt), 30)
                message = if (results.isEmpty()) {
                    "Não encontrei uma seleção para esse pedido."
                } else {
                    "Seleção criada com ${results.size} músicas."
                }
            } catch (_: Exception) {
                message = "Não consegui acessar o catálogo agora."
            }
            loading = false
        }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize().background(Bg),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("Nexa AI", color = TextPrimary, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
            Text("Peça uma seleção em linguagem natural.", color = TextSecondary)
        }

        item {
            Card(colors = CardDefaults.cardColors(containerColor = Surface1), shape = RoundedCornerShape(22.dp)) {
                Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = prompt,
                        onValueChange = { prompt = it },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3,
                        placeholder = { Text("Ex.: Quero sertanejo animado para viajar") },
                        shape = RoundedCornerShape(18.dp)
                    )
                    Button(
                        onClick = { createSelection() },
                        enabled = prompt.trim().length >= 2 && !loading,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (loading) CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                        else Icon(Icons.Rounded.AutoAwesome, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text(if (loading) "Criando…" else "Criar seleção")
                    }
                    Text(message, color = TextSecondary, fontSize = 13.sp)
                }
            }
        }

        if (results.isNotEmpty()) {
            item {
                Button(onClick = { onPlayQueue(results) }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Tocar seleção")
                }
            }
            items(results.take(15), key = { it.id }) { track ->
                TrackRow(track = track, onClick = { onPlayQueue(listOf(track)) })
            }
        }
    }
}

@Composable
private fun LibraryScreen(
    modifier: Modifier,
    liked: List<Track>,
    history: List<Track>,
    playlists: Map<String, List<Track>>,
    onPlay: (Track) -> Unit,
    onCreatePlaylist: (String) -> Unit,
    onRemoveFromPlaylist: (String, Track) -> Unit,
    onDeletePlaylist: (String) -> Unit
) {
    var showCreateDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier.fillMaxSize().background(Bg),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Biblioteca", color = TextPrimary, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Curtidas, histórico e playlists.", color = TextSecondary)
                }
                FilledIconButton(onClick = { showCreateDialog = true }) {
                    Icon(Icons.Rounded.Add, contentDescription = "Nova playlist")
                }
            }
        }

        item { SectionHeader("Curtidas", "${liked.size} músicas") }
        if (liked.isEmpty()) {
            item { HintBlock("Curta uma música no player para ela aparecer aqui.") }
        } else {
            items(liked.take(12), key = { "liked-${it.id}" }) { track ->
                TrackRow(track = track, onClick = { onPlay(track) })
            }
        }

        item { SectionHeader("Histórico", "Ouvidas recentemente") }
        if (history.isEmpty()) {
            item { HintBlock("Seu histórico aparece depois que você reproduz músicas.") }
        } else {
            items(history.take(12), key = { "history-${it.id}" }) { track ->
                TrackRow(track = track, onClick = { onPlay(track) })
            }
        }

        item { SectionHeader("Playlists", "${playlists.size} criadas") }
        if (playlists.isEmpty()) {
            item { HintBlock("Use o botão + para criar sua primeira playlist.") }
        } else {
            playlists.forEach { (name, tracks) ->
                item(key = "playlist-$name") {
                    PlaylistCard(
                        name = name,
                        tracks = tracks,
                        onPlay = onPlay,
                        onRemove = { track -> onRemoveFromPlaylist(name, track) },
                        onDelete = { onDeletePlaylist(name) }
                    )
                }
            }
        }
    }

    if (showCreateDialog) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text("Nova playlist") },
            text = {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    singleLine = true,
                    placeholder = { Text("Nome da playlist") }
                )
            },
            confirmButton = {
                TextButton(
                    onClick = { onCreatePlaylist(name); showCreateDialog = false },
                    enabled = name.isNotBlank()
                ) { Text("Criar") }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) { Text("Cancelar") }
            }
        )
    }
}

@Composable
private fun PlaylistCard(
    name: String,
    tracks: List<Track>,
    onPlay: (Track) -> Unit,
    onRemove: (Track) -> Unit,
    onDelete: () -> Unit
) {
    Card(colors = CardDefaults.cardColors(containerColor = Surface1), shape = RoundedCornerShape(20.dp)) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.QueueMusic, contentDescription = null, tint = Blue)
                Spacer(Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(name, color = TextPrimary, fontWeight = FontWeight.Bold)
                    Text("${tracks.size} músicas", color = TextSecondary, fontSize = 12.sp)
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Rounded.Delete, contentDescription = "Excluir playlist")
                }
            }
            tracks.take(5).forEach { track ->
                Row(
                    modifier = Modifier.fillMaxWidth().clickable { onPlay(track) }.padding(vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AsyncImage(
                        model = track.artworkUrl,
                        contentDescription = null,
                        modifier = Modifier.size(40.dp).clip(RoundedCornerShape(9.dp))
                    )
                    Spacer(Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(track.title, color = TextPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(track.artist, color = TextSecondary, fontSize = 12.sp, maxLines = 1)
                    }
                    IconButton(onClick = { onRemove(track) }) {
                        Icon(Icons.Rounded.Delete, contentDescription = "Remover")
                    }
                }
            }
        }
    }
}

@Composable
private fun ProfileScreen(
    modifier: Modifier,
    onOpenCatalog: () -> Unit
) {
    val context = LocalContext.current
    var dialog by remember { mutableStateOf<ProfileDialog?>(null) }

    LazyColumn(
        modifier = modifier.fillMaxSize().background(Bg),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("Perfil", color = TextPrimary, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
            Text("Preferências e informações do Nexa Music.", color = TextSecondary)
        }

        item {
            Card(colors = CardDefaults.cardColors(containerColor = Surface1), shape = RoundedCornerShape(22.dp)) {
                Row(modifier = Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier.size(54.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Purple, Blue))),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("JP", color = Color.White, fontWeight = FontWeight.ExtraBold)
                    }
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text("Nexa Music", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("Audius conectado • streaming completo", color = Success, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }

        item {
            MenuRow(
                Icons.Rounded.Settings,
                "Configurações",
                "Permissões, notificações e informações do aplicativo",
                onClick = { dialog = ProfileDialog.SETTINGS }
            )
        }
        item {
            MenuRow(
                Icons.Rounded.Headphones,
                "Segundo plano",
                "Controles do sistema e tela bloqueada",
                onClick = { dialog = ProfileDialog.BACKGROUND }
            )
        }
        item {
            MenuRow(
                Icons.Rounded.Search,
                "Catálogo",
                "Buscar músicas disponíveis no Audius",
                onClick = onOpenCatalog
            )
        }
        item {
            MenuRow(
                Icons.Rounded.Info,
                "Sobre as músicas",
                "Faixas públicas completas e limitações do catálogo",
                onClick = { dialog = ProfileDialog.ABOUT_MUSIC }
            )
        }
        item { Spacer(Modifier.height(22.dp)) }

        item {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                Text("Sobre o Nexa Music", color = TextSecondary, fontWeight = FontWeight.SemiBold)
                Text("Nexa Music", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("Criado por J. Pastore", color = Blue, fontWeight = FontWeight.Bold)
                Text("Powered by Nexa AI", color = Purple)
                Text("© 2026 • Versão 4.0.0", color = TextSecondary, fontSize = 12.sp)
            }
        }
    }

    when (dialog) {
        ProfileDialog.SETTINGS -> {
            AlertDialog(
                onDismissRequest = { dialog = null },
                title = { Text("Configurações") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Player", fontWeight = FontWeight.Bold)
                        Text(
                            "O Nexa Music usa o player Media3 para reprodução, fila, controles do sistema e tela bloqueada.",
                            color = TextSecondary,
                            fontSize = 13.sp
                        )
                        Text("Aplicativo", fontWeight = FontWeight.Bold)
                        Text(
                            "Abra as configurações do Android para permissões, dados móveis, bateria, armazenamento e outras opções do Nexa Music.",
                            color = TextSecondary,
                            fontSize = 13.sp
                        )
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        openNexaAppSettings(context)
                        dialog = null
                    }) { Text("Abrir configurações") }
                },
                dismissButton = {
                    TextButton(onClick = { dialog = null }) { Text("Fechar") }
                }
            )
        }

        ProfileDialog.BACKGROUND -> {
            AlertDialog(
                onDismissRequest = { dialog = null },
                title = { Text("Reprodução em segundo plano") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Ativo", color = Success, fontWeight = FontWeight.Bold)
                        Text(
                            "A música pode continuar tocando com o aplicativo em segundo plano e com a tela bloqueada. Os controles aparecem na notificação e na tela de bloqueio quando o Android permitir notificações do Nexa Music.",
                            color = TextSecondary,
                            fontSize = 13.sp
                        )
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        openNexaNotificationSettings(context)
                        dialog = null
                    }) { Text("Configurar notificações") }
                },
                dismissButton = {
                    TextButton(onClick = { dialog = null }) { Text("Fechar") }
                }
            )
        }

        ProfileDialog.ABOUT_MUSIC -> {
            AlertDialog(
                onDismissRequest = { dialog = null },
                title = { Text("Sobre as músicas") },
                text = {
                    Text(
                        "A Nexa Music v4 usa o catálogo aberto do Audius para reproduzir integralmente faixas públicas e não bloqueadas. Algumas músicas comerciais podem não existir no Audius e faixas com acesso protegido não são exibidas. Não é necessária assinatura de streaming para ouvir as faixas públicas disponíveis.",
                        color = TextSecondary,
                        fontSize = 13.sp
                    )
                },
                confirmButton = {
                    TextButton(onClick = { dialog = null }) { Text("Entendi") }
                }
            )
        }

        null -> Unit
    }
}

private enum class ProfileDialog {
    SETTINGS,
    BACKGROUND,
    ABOUT_MUSIC
}

private fun openNexaAppSettings(context: Context) {
    val intent = Intent(AndroidSettings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
        data = Uri.parse("package:${context.packageName}")
    }
    context.startActivity(intent)
}

private fun openNexaNotificationSettings(context: Context) {
    val intent = Intent(AndroidSettings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
        putExtra(AndroidSettings.EXTRA_APP_PACKAGE, context.packageName)
    }
    context.startActivity(intent)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AlbumDetailSheet(
    seed: Track,
    onDismiss: () -> Unit,
    onPlayQueue: (List<Track>, Track) -> Unit
) {
    var tracks by remember(seed.collectionId) { mutableStateOf<List<Track>>(emptyList()) }
    var loading by remember(seed.collectionId) { mutableStateOf(true) }
    var error by remember(seed.collectionId) { mutableStateOf<String?>(null) }

    LaunchedEffect(seed.collectionId) {
        loading = true
        error = null
        try {
            val loaded = CatalogRepository.albumTracks(seed.collectionId)
            tracks = if (loaded.isEmpty()) listOf(seed) else loaded
        } catch (_: Exception) {
            tracks = listOf(seed)
            error = "Não foi possível carregar todas as faixas desta coleção."
        }
        loading = false
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Surface1,
        contentColor = TextPrimary
    ) {
        LazyColumn(
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AsyncImage(
                        model = seed.artworkUrl,
                        contentDescription = "Capa de ${seed.album}",
                        modifier = Modifier.size(110.dp).clip(RoundedCornerShape(18.dp))
                    )
                    Spacer(Modifier.width(16.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(seed.album, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                        Text(seed.artist, color = TextSecondary)
                        if (seed.genre.isNotBlank()) Text(seed.genre, color = Blue, fontSize = 12.sp)
                    }
                }
            }

            if (loading) {
                item { LoadingBlock("Carregando coleção…") }
            } else {
                if (error != null) item { Text(error ?: "", color = Danger, fontSize = 12.sp) }
                items(tracks, key = { "album-${it.id}" }) { track ->
                    TrackRow(track = track, onClick = { onPlayQueue(tracks, track) })
                }
            }
            item { Spacer(Modifier.height(20.dp)) }
        }
    }
}

@Composable
private fun FullPlayer(
    track: Track,
    controller: MediaController?,
    isPlaying: Boolean,
    isLiked: Boolean,
    shuffleEnabled: Boolean,
    repeatMode: Int,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onLike: () -> Unit,
    onPlaylist: () -> Unit,
    onShuffle: () -> Unit,
    onRepeat: () -> Unit
) {
    var position by remember(track.id) { mutableLongStateOf(0L) }
    var duration by remember(track.id) { mutableLongStateOf(30_000L) }

    LaunchedEffect(controller, track.id, isPlaying) {
        while (true) {
            val c = controller
            if (c != null) {
                position = c.currentPosition.coerceAtLeast(0L)
                val currentDuration = c.duration
                duration = max(if (currentDuration > 0L) currentDuration else 30_000L, 1L)
            }
            delay(500L)
        }
    }

    Column(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        AsyncImage(
            model = track.artworkUrl,
            contentDescription = "Capa de ${track.album}",
            modifier = Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(28.dp))
        )

        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(track.title, color = TextPrimary, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(track.artist, color = TextSecondary, fontSize = 16.sp)
                Text(track.album, color = Blue, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            IconButton(onClick = onLike) {
                Icon(
                    if (isLiked) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                    contentDescription = "Curtir",
                    tint = if (isLiked) Magenta else TextSecondary
                )
            }
        }

        Slider(
            value = position.coerceAtMost(duration).toFloat(),
            onValueChange = { value -> controller?.seekTo(value.toLong()) },
            valueRange = 0f..duration.toFloat().coerceAtLeast(1f),
            modifier = Modifier.fillMaxWidth()
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onShuffle) {
                Icon(Icons.Rounded.Shuffle, contentDescription = "Aleatório", tint = if (shuffleEnabled) Blue else TextSecondary)
            }
            IconButton(onClick = onPrevious) {
                Icon(Icons.Rounded.SkipPrevious, contentDescription = "Anterior", modifier = Modifier.size(36.dp))
            }
            FilledIconButton(
                onClick = onToggle,
                modifier = Modifier.size(68.dp),
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color.White, contentColor = Color.Black)
            ) {
                Icon(
                    if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    contentDescription = "Play ou pausar",
                    modifier = Modifier.size(38.dp)
                )
            }
            IconButton(onClick = onNext) {
                Icon(Icons.Rounded.SkipNext, contentDescription = "Próxima", modifier = Modifier.size(36.dp))
            }
            IconButton(onClick = onRepeat) {
                Icon(
                    if (repeatMode == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                    contentDescription = "Repetir",
                    tint = if (repeatMode == Player.REPEAT_MODE_OFF) TextSecondary else Blue
                )
            }
        }

        OutlinedButton(onClick = onPlaylist) {
            Icon(Icons.Rounded.PlaylistAdd, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Adicionar à playlist")
        }

        Text("A reprodução online desta etapa usa a prévia disponibilizada pelo catálogo.", color = TextSecondary, fontSize = 11.sp)
        Spacer(Modifier.height(18.dp))
    }
}

@Composable
private fun MiniPlayer(
    track: Track,
    isPlaying: Boolean,
    onOpen: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().background(Surface2).clickable { onOpen() }.padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AsyncImage(
            model = track.artworkUrl,
            contentDescription = null,
            modifier = Modifier.size(48.dp).clip(RoundedCornerShape(12.dp))
        )
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(track.title, color = TextPrimary, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(track.artist, color = TextSecondary, fontSize = 12.sp, maxLines = 1)
        }
        IconButton(onClick = onToggle) {
            Icon(if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, contentDescription = "Play ou pausar")
        }
        IconButton(onClick = onNext) {
            Icon(Icons.Rounded.SkipNext, contentDescription = "Próxima")
        }
    }
}

@Composable
private fun TrackRow(track: Track, onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().clickable { onClick() }.padding(vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Card(shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = Surface1)) {
            if (track.artworkUrl.isNotBlank()) {
                AsyncImage(
                    model = track.artworkUrl,
                    contentDescription = null,
                    modifier = Modifier.size(58.dp)
                )
            } else {
                Box(modifier = Modifier.size(58.dp), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.MusicNote, contentDescription = null, tint = Blue)
                }
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(track.title, color = TextPrimary, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${track.artist} • ${track.album}", color = TextSecondary, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Icon(Icons.Rounded.PlayArrow, contentDescription = "Tocar", tint = Blue)
    }
}

@Composable
private fun SectionHeader(title: String, subtitle: String) {
    Column {
        Text(title, color = TextPrimary, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
        Text(subtitle, color = TextSecondary, fontSize = 13.sp)
    }
}

@Composable
private fun LoadingBlock(text: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 22.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp)
        Spacer(Modifier.width(10.dp))
        Text(text, color = TextSecondary)
    }
}

@Composable
private fun ErrorBlock(text: String, onRetry: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Surface1), shape = RoundedCornerShape(18.dp)) {
        Row(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(text, color = Danger, modifier = Modifier.weight(1f), fontSize = 13.sp)
            IconButton(onClick = onRetry) {
                Icon(Icons.Rounded.Refresh, contentDescription = "Tentar novamente")
            }
        }
    }
}

@Composable
private fun HintBlock(text: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Surface1), shape = RoundedCornerShape(16.dp)) {
        Text(text, color = TextSecondary, fontSize = 13.sp, modifier = Modifier.fillMaxWidth().padding(14.dp))
    }
}

@Composable
private fun MenuRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = Surface1),
        shape = RoundedCornerShape(18.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = Blue)
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, color = TextPrimary, fontWeight = FontWeight.Bold)
                Text(subtitle, color = TextSecondary, fontSize = 12.sp)
            }
            Text("›", color = TextSecondary, fontSize = 24.sp, fontWeight = FontWeight.Light)
        }
    }
}

@Composable
private fun AddToPlaylistDialog(
    playlistNames: List<String>,
    onDismiss: () -> Unit,
    onAdd: (String) -> Unit,
    onCreateAndAdd: (String) -> Unit
) {
    var name by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Adicionar à playlist") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                playlistNames.forEach { playlist ->
                    OutlinedButton(onClick = { onAdd(playlist) }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Rounded.QueueMusic, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text(playlist, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    singleLine = true,
                    placeholder = { Text("Nova playlist") }
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onCreateAndAdd(name) },
                enabled = name.isNotBlank()
            ) { Text("Criar e adicionar") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar") }
        }
    )
}
