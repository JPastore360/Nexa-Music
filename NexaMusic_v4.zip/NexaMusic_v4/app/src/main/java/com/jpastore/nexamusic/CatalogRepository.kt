package com.jpastore.nexamusic

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Catálogo gratuito do Audius / Open Audio Protocol.
 *
 * A API pública permite consulta e streaming de faixas públicas. O app ignora
 * faixas marcadas como não reproduzíveis ou com stream protegido/gated.
 */
internal object CatalogRepository {
    private const val BASE_URL = "https://api.audius.co/v1"
    private const val APP_NAME = "NexaMusic"

    suspend fun searchSongs(term: String, limit: Int = 30): List<Track> = withContext(Dispatchers.IO) {
        val clean = term.trim()
        if (clean.length < 2) return@withContext emptyList()

        val encoded = URLEncoder.encode(clean, "UTF-8")
        val url = "$BASE_URL/tracks/search?query=$encoded&limit=${limit.coerceIn(1, 50)}&sort_method=relevant&app_name=$APP_NAME"
        parseTracks(request(url))
    }

    suspend fun homeTracks(): List<Track> = withContext(Dispatchers.IO) {
        // Trending é a fonte principal da Home. Se a rede/API não devolver itens,
        // fazemos buscas de descoberta para evitar uma tela vazia.
        val trendingUrl = "$BASE_URL/tracks/trending?time=week&limit=40&app_name=$APP_NAME"
        val trending = try {
            parseTracks(request(trendingUrl))
        } catch (_: Exception) {
            emptyList()
        }

        if (trending.isNotEmpty()) return@withContext trending.distinctBy { it.id }.take(36)

        val result = mutableListOf<Track>()
        val terms = listOf("electronic", "hip hop", "rock", "pop", "lofi")
        for (term in terms) {
            try {
                result.addAll(searchSongs(term, 10))
            } catch (_: Exception) {
                // continua tentando outras categorias
            }
        }
        result.distinctBy { it.id }.take(36)
    }

    suspend fun albumTracks(collectionId: String): List<Track> = withContext(Dispatchers.IO) {
        if (collectionId.isBlank()) return@withContext emptyList()

        val url = when {
            collectionId.startsWith("album:") -> {
                val id = collectionId.removePrefix("album:")
                "$BASE_URL/playlists/${encodePath(id)}/tracks?limit=50&app_name=$APP_NAME"
            }
            collectionId.startsWith("user:") -> {
                val id = collectionId.removePrefix("user:")
                "$BASE_URL/users/${encodePath(id)}/tracks?limit=50&app_name=$APP_NAME"
            }
            else -> return@withContext searchSongs(collectionId, 30)
        }

        parseTracks(request(url)).distinctBy { it.id }
    }

    fun albumsFrom(tracks: List<Track>): List<AlbumSummary> {
        val seen = mutableSetOf<String>()
        val albums = mutableListOf<AlbumSummary>()

        for (track in tracks) {
            if (track.collectionId.isBlank()) continue
            if (!seen.add(track.collectionId)) continue

            albums += AlbumSummary(
                collectionId = track.collectionId,
                title = track.album.ifBlank { "Mais de ${track.artist}" },
                artist = track.artist,
                artworkUrl = track.artworkUrl,
                genre = track.genre,
                seedTrack = track
            )
        }
        return albums
    }

    private fun request(urlString: String): String {
        val connection = URL(urlString).openConnection() as HttpURLConnection
        connection.connectTimeout = 12_000
        connection.readTimeout = 18_000
        connection.requestMethod = "GET"
        connection.instanceFollowRedirects = true
        connection.setRequestProperty("Accept", "application/json")
        connection.setRequestProperty("User-Agent", "NexaMusic/4.0 Android")

        return try {
            val status = connection.responseCode
            if (status !in 200..299) throw IllegalStateException("HTTP $status")
            connection.inputStream.bufferedReader().use { it.readText() }
        } finally {
            connection.disconnect()
        }
    }

    private fun parseTracks(json: String): List<Track> {
        val root = JSONObject(json)
        val array = extractDataArray(root) ?: return emptyList()
        val tracks = mutableListOf<Track>()

        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            val id = item.optString("id", "").trim()
            if (id.isBlank()) continue

            // Não exibimos faixas que a própria API marca como indisponíveis
            // para stream público/gratuito.
            if (!isStreamable(item)) continue
            if (isStreamGated(item)) continue

            val title = item.optString("title", "Música").ifBlank { "Música" }
            val genre = item.optString("genre", "Música").ifBlank { "Música" }
            val user = item.optJSONObject("user")
            val artistName = user?.optString("name", "").orEmpty()
            val artistHandle = user?.optString("handle", "").orEmpty()
            val artist = firstNonBlank(artistName, artistHandle, "Artista")
            val userId = user?.optString("id", "") ?: ""

            val artwork = bestArtwork(item.optJSONObject("artwork"))
            val albumBacklink = item.optJSONObject("album_backlink")
                ?: item.optJSONObject("albumBacklink")

            val albumId = firstNonBlank(
                albumBacklink?.optString("playlist_id", ""),
                albumBacklink?.optString("playlistId", ""),
                albumBacklink?.optString("id", "")
            )
            val albumName = firstNonBlank(
                albumBacklink?.optString("playlist_name", ""),
                albumBacklink?.optString("playlistName", ""),
                albumBacklink?.optString("name", "")
            )

            val collectionId: String
            val album: String
            if (albumId.isNotBlank()) {
                collectionId = "album:$albumId"
                album = albumName.ifBlank { "Álbum" }
            } else if (userId.isNotBlank()) {
                collectionId = "user:$userId"
                album = "Mais de $artist"
            } else {
                collectionId = "search:$artist"
                album = "Mais de $artist"
            }

            val seconds = item.optLong("duration", 0L).coerceAtLeast(0L)
            val streamUrl = "$BASE_URL/tracks/${encodePath(id)}/stream?app_name=$APP_NAME"

            tracks += Track(
                id = id,
                title = title,
                artist = artist,
                album = album,
                streamUrl = streamUrl,
                artworkUrl = artwork,
                genre = genre,
                collectionId = collectionId,
                durationMs = seconds * 1000L,
                trackNumber = 0
            )
        }

        return tracks.distinctBy { it.id }
    }

    private fun extractDataArray(root: JSONObject): JSONArray? {
        val data = root.opt("data")
        return when (data) {
            is JSONArray -> data
            is JSONObject -> {
                data.optJSONArray("tracks")
                    ?: data.optJSONArray("results")
                    ?: data.optJSONArray("data")
            }
            else -> root.optJSONArray("results")
        }
    }

    private fun bestArtwork(artwork: JSONObject?): String {
        if (artwork == null) return ""
        return firstNonBlank(
            artwork.optString("1000x1000", ""),
            artwork.optString("_1000x1000", ""),
            artwork.optString("480x480", ""),
            artwork.optString("_480x480", ""),
            artwork.optString("150x150", ""),
            artwork.optString("_150x150", "")
        ).replace("http://", "https://")
    }

    private fun isStreamable(item: JSONObject): Boolean {
        val raw = if (item.has("is_streamable")) item.opt("is_streamable") else item.opt("isStreamable")
        return when (raw) {
            null, JSONObject.NULL -> true
            is Boolean -> raw
            is Number -> raw.toInt() != 0
            is String -> raw.equals("true", ignoreCase = true) || raw == "1"
            else -> true
        }
    }

    private fun isStreamGated(item: JSONObject): Boolean {
        val raw = if (item.has("is_stream_gated")) item.opt("is_stream_gated") else item.opt("isStreamGated")
        return when (raw) {
            is Boolean -> raw
            is Number -> raw.toInt() != 0
            is String -> raw.equals("true", ignoreCase = true) || raw == "1"
            else -> false
        }
    }

    private fun firstNonBlank(vararg values: String?): String =
        values.firstOrNull { !it.isNullOrBlank() }?.trim().orEmpty()

    private fun encodePath(value: String): String =
        URLEncoder.encode(value, "UTF-8").replace("+", "%20")
}
