# Nexa Music v7

Versão 7.0.0.

## Busca Multi-Engine

A v7 separa **descoberta** de **reprodução**. O objetivo é que uma pesquisa por uma música conhecida não retorne simplesmente “nenhum resultado” só porque o Audius/Jamendo não possuem aquela faixa.

Motores usados:

- **Backend comercial Nexa**, quando `MUSIC_BACKEND_URL` estiver configurado.
- **Audius** para faixas completas públicas disponíveis.
- **Jamendo** para faixas completas quando `JAMENDO_CLIENT_ID` estiver configurado.
- **MusicBrainz** como catálogo global de referência.
- **Apple/iTunes Search** como motor auxiliar de descoberta e normalização de título/artista; previews não são usados como reprodução principal.
- **Deezer Search** como referência adicional de metadados, com falha silenciosa caso o endpoint não esteja disponível.

A busca também gera variações da consulta (artista + música, música + artista, remoção de parênteses etc.) e tenta casar o resultado global com uma faixa completa das fontes gratuitas.

Na interface os resultados são separados em:

- **Disponíveis para tocar** — o app possui URL de streaming integral autorizada pela fonte.
- **Encontradas no catálogo global** — a Nexa identificou a música/álbum/artista, mas não encontrou um stream integral gratuito autorizado. Esses itens não exibem botão de Play.

## Login e atualização por cima

O `applicationId` continua `com.jpastore.nexamusic`. A v7 reutiliza exatamente o mesmo `app/nexa-test.keystore` introduzido na v5/v6, portanto pode ser instalada por cima de uma v5/v6 assinada com essa chave, preservando contas locais, favoritos, histórico e playlists.

O nome de SharedPreferences de contas locais continua intencionalmente `nexa_music_local_accounts_v6` para preservar os cadastros existentes.

## Secrets opcionais

- `SUPABASE_URL`
- `SUPABASE_ANON_KEY`
- `JAMENDO_CLIENT_ID`
- `MUSIC_BACKEND_URL`

A ausência desses secrets não impede a compilação; o app mantém login local e as fontes públicas disponíveis.

Criado por J. Pastore • Powered by Nexa AI
