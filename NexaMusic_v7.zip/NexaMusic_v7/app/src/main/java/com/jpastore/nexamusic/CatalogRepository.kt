package com.jpastore.nexamusic

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.Normalizer
import java.util.Locale

/**
 * Catálogo híbrido Nexa Music.
 *
 * - Audius: busca + streaming integral de faixas públicas.
 * - Jamendo: busca + streaming integral quando um JAMENDO_CLIENT_ID estiver configurado.
 * - iTunes Search: somente descoberta/metadados para melhorar a interpretação da pesquisa;
 *   nunca usamos preview como resultado principal. Os metadados viram novas tentativas de
 *   correspondência nas fontes que permitem streaming integral.
 */
internal object CatalogRepository {
    private const val AUDIUS_BASE = "https://api.audius.co/v1"
    private const val ITUNES_BASE = "https://itunes.apple.com/search"
    private const val JAMENDO_BASE = "https://api.jamendo.com/v3.0/tracks/"
    private const val MUSICBRAINZ_BASE = "https://musicbrainz.org/ws/2/recording/"
    private const val DEEZER_SEARCH_BASE = "https://api.deezer.com/search"
    private const val APP_NAME = "NexaMusic"

    val jamendoEnabled: Boolean
        get() = BuildConfig.JAMENDO_CLIENT_ID.isNotBlank()

    val commercialBackendEnabled: Boolean
        get() = BuildConfig.MUSIC_BACKEND_URL.isNotBlank()

    suspend fun searchSongs(term: String, limit: Int = 60): List<Track> = withContext(Dispatchers.IO) {
        val clean = term.trim()
        if (clean.length < 2) return@withContext emptyList()

        // 1) Primeiro procura versões realmente reproduzíveis.
        val variants = queryVariants(clean).take(4)
        val directPlayable = coroutineScope {
            val jobs = mutableListOf<kotlinx.coroutines.Deferred<List<Track>>>()
            jobs += async { safeCommercialSearch(clean, 36) }
            for (variant in variants) {
                jobs += async { safeAudiusSearch(variant, 22) }
                jobs += async { safeJamendoSearch(variant, 18) }
            }
            jobs.awaitAll().flatten()
        }.toMutableList()

        // 2) Em paralelo consulta catálogos globais apenas para IDENTIFICAR a música correta.
        // Essas fontes não viram streaming completo automaticamente.
        val discoverySources = coroutineScope {
            listOf(
                async { safeAppleDiscovery(clean, 18) },
                async { safeMusicBrainzDiscovery(clean, 18) },
                async { safeDeezerDiscovery(clean, 18) }
            ).awaitAll().flatten()
        }

        // 3) Com título/artista normalizados, tenta novamente nas fontes de faixa completa.
        val expandedPlayable = coroutineScope {
            discoverySources
                .distinctBy { normalize("${it.artist}|${it.title}") }
                .take(8)
                .map { candidate ->
                    async {
                        val q = "${candidate.artist} ${candidate.title}".trim()
                        val candidates = safeAudiusSearch(q, 10) + safeJamendoSearch(q, 8)
                        candidates
                            .map { it to matchScore(it, candidate.title, candidate.artist) }
                            .filter { it.second >= 0.50 }
                            .sortedByDescending { it.second }
                            .take(2)
                            .map { it.first }
                    }
                }.awaitAll().flatten()
        }

        directPlayable += expandedPlayable
        val playable = rankResults(directPlayable.distinctBy { it.id }, clean)

        // 4) Mesmo quando não existe stream gratuito, mostramos que a música foi encontrada.
        // Evita a sensação de "a busca não acha nada" e separa descoberta de reprodução.
        val playableKeys = playable.map { normalize("${it.artist}|${it.title}") }.toSet()
        val references = discoverySources
            .filter { normalize("${it.artist}|${it.title}") !in playableKeys }
            .distinctBy { normalize("${it.artist}|${it.title}") }
            .sortedByDescending { referenceScore(it, clean) }

        (playable + references).take(limit.coerceIn(1, 80))
    }

    suspend fun homeTracks(): List<Track> = withContext(Dispatchers.IO) {
        val combined = coroutineScope {
            listOf(
                async { safeCommercialHome() },
                async { safeAudiusTrending() },
                async { safeJamendoPopular() }
            ).awaitAll().flatten()
        }

        if (combined.isNotEmpty()) {
            return@withContext combined.distinctBy { it.id }.take(42)
        }

        val fallback = mutableListOf<Track>()
        for (term in listOf("pop", "rock", "electronic", "hip hop", "lofi", "acoustic")) {
            fallback += searchSongs(term, 12).filter { it.isPlayable }
        }
        fallback.distinctBy { it.id }.take(36)
    }

    suspend fun albumTracks(collectionId: String): List<Track> = withContext(Dispatchers.IO) {
        if (collectionId.isBlank()) return@withContext emptyList()

        when {
            collectionId.startsWith("backend-album:") -> {
                val albumId = collectionId.removePrefix("backend-album:")
                safeCommercialAlbum(albumId)
            }
            collectionId.startsWith("jamendo-album:") -> {
                val albumId = collectionId.removePrefix("jamendo-album:")
                safeJamendoAlbum(albumId)
            }
            collectionId.startsWith("album:") -> {
                val id = collectionId.removePrefix("album:")
                parseAudiusTracks(request("$AUDIUS_BASE/playlists/${encodePath(id)}/tracks?limit=50&app_name=$APP_NAME"))
            }
            collectionId.startsWith("user:") -> {
                val id = collectionId.removePrefix("user:")
                parseAudiusTracks(request("$AUDIUS_BASE/users/${encodePath(id)}/tracks?limit=50&app_name=$APP_NAME"))
            }
            else -> searchSongs(collectionId, 30)
        }.distinctBy { it.id }
    }

    fun albumsFrom(tracks: List<Track>): List<AlbumSummary> {
        val seen = mutableSetOf<String>()
        val albums = mutableListOf<AlbumSummary>()
        for (track in tracks) {
            if (!track.isPlayable || track.collectionId.isBlank() || !seen.add(track.collectionId)) continue
            albums += AlbumSummary(
                collectionId = track.collectionId,
                title = track.album.ifBlank { "Mais de ${track.artist}" },
                artist = track.artist,
                artworkUrl = track.artworkUrl,
                genre = track.genre,
                seedTrack = track
            )
        }
        return albums
    }


    private suspend fun safeCommercialSearch(term: String, limit: Int): List<Track> = withContext(Dispatchers.IO) {
        if (!commercialBackendEnabled) return@withContext emptyList()
        try {
            val encoded = URLEncoder.encode(term, "UTF-8")
            val base = BuildConfig.MUSIC_BACKEND_URL.trimEnd('/')
            parseCommercialTracks(request("$base/v1/search?query=$encoded&limit=${limit.coerceIn(1, 50)}"))
        } catch (_: Exception) { emptyList() }
    }

    private suspend fun safeCommercialHome(): List<Track> = withContext(Dispatchers.IO) {
        if (!commercialBackendEnabled) return@withContext emptyList()
        try {
            val base = BuildConfig.MUSIC_BACKEND_URL.trimEnd('/')
            parseCommercialTracks(request("$base/v1/home?limit=36"))
        } catch (_: Exception) { emptyList() }
    }

    private suspend fun safeCommercialAlbum(albumId: String): List<Track> = withContext(Dispatchers.IO) {
        if (!commercialBackendEnabled) return@withContext emptyList()
        try {
            val base = BuildConfig.MUSIC_BACKEND_URL.trimEnd('/')
            parseCommercialTracks(request("$base/v1/albums/${encodePath(albumId)}/tracks?limit=100"))
        } catch (_: Exception) { emptyList() }
    }

    /**
     * Contrato normalizado do backend Nexa para provedores comerciais.
     * As credenciais de Tuned Global / MassiveMusic ficam no servidor, nunca no APK.
     */
    private fun parseCommercialTracks(json: String): List<Track> {
        val root = JSONObject(json)
        val array = root.optJSONArray("tracks")
            ?: root.optJSONArray("data")
            ?: root.optJSONObject("data")?.optJSONArray("tracks")
            ?: return emptyList()
        val tracks = mutableListOf<Track>()
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            val rawId = item.optString("id").trim()
            val streamUrl = item.optString("streamUrl").trim()
            if (rawId.isBlank() || streamUrl.isBlank()) continue
            val albumId = item.optString("albumId").trim()
            val provider = item.optString("provider", "Premium").ifBlank { "Premium" }
            tracks += Track(
                id = "backend:$rawId",
                title = item.optString("title", "Música").ifBlank { "Música" },
                artist = item.optString("artist", "Artista").ifBlank { "Artista" },
                album = item.optString("album", "Álbum").ifBlank { "Álbum" },
                streamUrl = streamUrl,
                artworkUrl = item.optString("artworkUrl").trim(),
                genre = item.optString("genre").ifBlank { "$provider • faixa licenciada" },
                collectionId = if (albumId.isNotBlank()) "backend-album:$albumId" else "",
                durationMs = item.optLong("durationMs", 0L).coerceAtLeast(0L),
                trackNumber = item.optInt("trackNumber", 0)
            )
        }
        return tracks.distinctBy { it.id }
    }

    private suspend fun safeAudiusSearch(term: String, limit: Int): List<Track> = withContext(Dispatchers.IO) {
        try {
            val encoded = URLEncoder.encode(term, "UTF-8")
            val url = "$AUDIUS_BASE/tracks/search?query=$encoded&limit=${limit.coerceIn(1, 50)}&sort_method=relevant&app_name=$APP_NAME"
            parseAudiusTracks(request(url))
        } catch (_: Exception) { emptyList() }
    }

    private suspend fun safeAudiusTrending(): List<Track> = withContext(Dispatchers.IO) {
        try {
            parseAudiusTracks(request("$AUDIUS_BASE/tracks/trending?time=week&limit=32&app_name=$APP_NAME"))
        } catch (_: Exception) { emptyList() }
    }

    private suspend fun safeJamendoSearch(term: String, limit: Int): List<Track> = withContext(Dispatchers.IO) {
        if (!jamendoEnabled) return@withContext emptyList()
        try {
            val encoded = URLEncoder.encode(term, "UTF-8")
            val url = "$JAMENDO_BASE?client_id=${encodePath(BuildConfig.JAMENDO_CLIENT_ID)}&format=json&limit=${limit.coerceIn(1, 50)}&search=$encoded&order=relevance&audioformat=mp32&imagesize=500&type=single+albumtrack"
            parseJamendoTracks(request(url))
        } catch (_: Exception) { emptyList() }
    }

    private suspend fun safeJamendoPopular(): List<Track> = withContext(Dispatchers.IO) {
        if (!jamendoEnabled) return@withContext emptyList()
        try {
            val url = "$JAMENDO_BASE?client_id=${encodePath(BuildConfig.JAMENDO_CLIENT_ID)}&format=json&limit=20&order=popularity_month_desc&audioformat=mp32&imagesize=500&type=single+albumtrack"
            parseJamendoTracks(request(url))
        } catch (_: Exception) { emptyList() }
    }

    private suspend fun safeJamendoAlbum(albumId: String): List<Track> = withContext(Dispatchers.IO) {
        if (!jamendoEnabled) return@withContext emptyList()
        try {
            val url = "$JAMENDO_BASE?client_id=${encodePath(BuildConfig.JAMENDO_CLIENT_ID)}&format=json&limit=100&album_id=${encodePath(albumId)}&order=id&audioformat=mp32&imagesize=500&type=single+albumtrack"
            parseJamendoTracks(request(url))
        } catch (_: Exception) { emptyList() }
    }

    private fun safeAppleDiscovery(term: String, limit: Int): List<Track> = try {
        val encoded = URLEncoder.encode(term, "UTF-8")
        val url = "$ITUNES_BASE?term=$encoded&media=music&entity=song&limit=${limit.coerceIn(1, 30)}&country=BR"
        val root = JSONObject(request(url))
        val array = root.optJSONArray("results") ?: JSONArray()
        val out = mutableListOf<Track>()
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            val id = item.optString("trackId").trim()
            val title = item.optString("trackName").trim()
            val artist = item.optString("artistName").trim()
            if (id.isBlank() || title.isBlank() || artist.isBlank()) continue
            out += Track(
                id = "apple-ref:$id",
                title = title,
                artist = artist,
                album = item.optString("collectionName", "Álbum").ifBlank { "Álbum" },
                streamUrl = "",
                artworkUrl = "", // metadado de referência; sem usar preview como entretenimento
                genre = "Catálogo global • referência",
                collectionId = "",
                durationMs = item.optLong("trackTimeMillis", 0L).coerceAtLeast(0L),
                trackNumber = item.optInt("trackNumber", 0)
            )
        }
        out
    } catch (_: Exception) { emptyList() }

    private fun safeMusicBrainzDiscovery(term: String, limit: Int): List<Track> = try {
        val encoded = URLEncoder.encode(term, "UTF-8")
        val url = "$MUSICBRAINZ_BASE?query=$encoded&fmt=json&limit=${limit.coerceIn(1, 25)}"
        val root = JSONObject(request(url))
        val array = root.optJSONArray("recordings") ?: JSONArray()
        val out = mutableListOf<Track>()
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            val id = item.optString("id").trim()
            val title = item.optString("title").trim()
            val credits = item.optJSONArray("artist-credit") ?: JSONArray()
            val artists = mutableListOf<String>()
            for (j in 0 until credits.length()) {
                val credit = credits.optJSONObject(j) ?: continue
                val name = credit.optString("name").ifBlank { credit.optJSONObject("artist")?.optString("name").orEmpty() }
                if (name.isNotBlank()) artists += name
            }
            val artist = artists.joinToString(" & ").ifBlank { "Artista" }
            if (id.isBlank() || title.isBlank()) continue
            val releases = item.optJSONArray("releases")
            val album = releases?.optJSONObject(0)?.optString("title").orEmpty().ifBlank { "Catálogo global" }
            out += Track(
                id = "mb-ref:$id",
                title = title,
                artist = artist,
                album = album,
                streamUrl = "",
                artworkUrl = "",
                genre = "Catálogo global • MusicBrainz",
                collectionId = "",
                durationMs = item.optLong("length", 0L).coerceAtLeast(0L),
                trackNumber = 0
            )
        }
        out
    } catch (_: Exception) { emptyList() }

    private fun safeDeezerDiscovery(term: String, limit: Int): List<Track> = try {
        val encoded = URLEncoder.encode(term, "UTF-8")
        val root = JSONObject(request("$DEEZER_SEARCH_BASE?q=$encoded&limit=${limit.coerceIn(1, 25)}"))
        val array = root.optJSONArray("data") ?: JSONArray()
        val out = mutableListOf<Track>()
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            val id = item.optString("id").trim()
            val title = item.optString("title").trim()
            val artist = item.optJSONObject("artist")?.optString("name").orEmpty().trim()
            if (id.isBlank() || title.isBlank() || artist.isBlank()) continue
            out += Track(
                id = "deezer-ref:$id",
                title = title,
                artist = artist,
                album = item.optJSONObject("album")?.optString("title").orEmpty().ifBlank { "Álbum" },
                streamUrl = "",
                artworkUrl = "",
                genre = "Catálogo global • referência",
                collectionId = "",
                durationMs = item.optLong("duration", 0L).coerceAtLeast(0L) * 1000L,
                trackNumber = 0
            )
        }
        out
    } catch (_: Exception) { emptyList() }

    private fun queryVariants(term: String): List<String> {
        val cleaned = term
            .replace(Regex("\\([^)]*\\)"), " ")
            .replace(Regex("\\[[^]]*]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
        val variants = linkedSetOf<String>()
        variants += term.trim()
        if (cleaned.isNotBlank()) variants += cleaned
        val separators = listOf(" - ", " – ", " — ", " | ")
        for (sep in separators) {
            if (term.contains(sep)) {
                val parts = term.split(sep, limit = 2).map { it.trim() }
                if (parts.size == 2 && parts.all { it.isNotBlank() }) {
                    variants += "${parts[0]} ${parts[1]}"
                    variants += "${parts[1]} ${parts[0]}"
                }
            }
        }
        return variants.filter { it.length >= 2 }
    }

    private fun referenceScore(track: Track, query: String): Double {
        val nq = normalize(query)
        val title = normalize(track.title)
        val artist = normalize(track.artist)
        val exact = if (title == nq || "$artist $title" == nq || "$title $artist" == nq) 4.0 else 0.0
        val contains = if (title.contains(nq) || artist.contains(nq) || nq.contains(title)) 1.5 else 0.0
        return exact + contains + tokenScore("$title $artist", nq)
    }

    private fun parseJamendoTracks(json: String): List<Track> {
        val root = JSONObject(json)
        val results = root.optJSONArray("results") ?: return emptyList()
        val tracks = mutableListOf<Track>()
        for (i in 0 until results.length()) {
            val item = results.optJSONObject(i) ?: continue
            val rawId = item.optString("id").trim()
            val audio = item.optString("audio").trim().replace("http://", "https://")
            if (rawId.isBlank() || audio.isBlank()) continue

            val artist = item.optString("artist_name", "Artista").ifBlank { "Artista" }
            val albumId = item.optString("album_id").trim()
            val albumName = item.optString("album_name").trim().ifBlank { "Single" }
            val image = firstNonBlank(item.optString("image"), item.optString("album_image")).replace("http://", "https://")
            val seconds = item.optLong("duration", 0L).coerceAtLeast(0L)

            tracks += Track(
                id = "jamendo:$rawId",
                title = item.optString("name", "Música").ifBlank { "Música" },
                artist = artist,
                album = albumName,
                streamUrl = audio,
                artworkUrl = image,
                genre = "Jamendo • faixa completa",
                collectionId = if (albumId.isNotBlank()) "jamendo-album:$albumId" else "jamendo-artist:${normalize(artist)}",
                durationMs = seconds * 1000L,
                trackNumber = item.optInt("position", 0)
            )
        }
        return tracks
    }

    private fun parseAudiusTracks(json: String): List<Track> {
        val root = JSONObject(json)
        val array = extractDataArray(root) ?: return emptyList()
        val tracks = mutableListOf<Track>()

        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            val id = item.optString("id", "").trim()
            if (id.isBlank() || !isStreamable(item) || isStreamGated(item)) continue

            val title = item.optString("title", "Música").ifBlank { "Música" }
            val rawGenre = item.optString("genre", "Música").ifBlank { "Música" }
            val user = item.optJSONObject("user")
            val artist = firstNonBlank(user?.optString("name"), user?.optString("handle"), "Artista")
            val userId = user?.optString("id", "").orEmpty()
            val artwork = bestArtwork(item.optJSONObject("artwork"))
            val albumBacklink = item.optJSONObject("album_backlink") ?: item.optJSONObject("albumBacklink")
            val albumId = firstNonBlank(
                albumBacklink?.optString("playlist_id"),
                albumBacklink?.optString("playlistId"),
                albumBacklink?.optString("id")
            )
            val albumName = firstNonBlank(
                albumBacklink?.optString("playlist_name"),
                albumBacklink?.optString("playlistName"),
                albumBacklink?.optString("name")
            )

            val collectionId = when {
                albumId.isNotBlank() -> "album:$albumId"
                userId.isNotBlank() -> "user:$userId"
                else -> "search:$artist"
            }
            val album = if (albumId.isNotBlank()) albumName.ifBlank { "Álbum" } else "Mais de $artist"
            val seconds = item.optLong("duration", 0L).coerceAtLeast(0L)

            tracks += Track(
                id = "audius:$id",
                title = title,
                artist = artist,
                album = album,
                streamUrl = "$AUDIUS_BASE/tracks/${encodePath(id)}/stream?app_name=$APP_NAME",
                artworkUrl = artwork,
                genre = "$rawGenre • Audius",
                collectionId = collectionId,
                durationMs = seconds * 1000L,
                trackNumber = 0
            )
        }
        return tracks.distinctBy { it.id }
    }

    private fun rankResults(items: List<Track>, query: String): List<Track> {
        val nq = normalize(query)
        return items.sortedByDescending { track ->
            val title = normalize(track.title)
            val artist = normalize(track.artist)
            val exactTitle = if (title == nq) 2.5 else 0.0
            val contains = if (title.contains(nq) || artist.contains(nq)) 1.2 else 0.0
            exactTitle + contains + tokenScore("$title $artist", nq)
        }
    }

    private fun matchScore(track: Track, title: String, artist: String): Double {
        val titleScore = tokenScore(normalize(track.title), normalize(title))
        val artistScore = tokenScore(normalize(track.artist), normalize(artist))
        return (titleScore * 0.68) + (artistScore * 0.32)
    }

    private fun tokenScore(a: String, b: String): Double {
        val aa = a.split(' ').filter { it.length > 1 }.toSet()
        val bb = b.split(' ').filter { it.length > 1 }.toSet()
        if (aa.isEmpty() || bb.isEmpty()) return if (a == b) 1.0 else 0.0
        val intersection = aa.intersect(bb).size.toDouble()
        val union = aa.union(bb).size.toDouble().coerceAtLeast(1.0)
        return intersection / union
    }

    private fun normalize(value: String): String {
        val noAccent = Normalizer.normalize(value.lowercase(Locale.ROOT), Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "")
        return noAccent
            .replace(Regex("\\b(feat|ft|featuring|remaster(ed)?|live|official|audio|video)\\b.*"), " ")
            .replace(Regex("[^a-z0-9]+"), " ")
            .trim()
    }

    private fun request(urlString: String): String {
        val connection = URL(urlString).openConnection() as HttpURLConnection
        connection.connectTimeout = 12_000
        connection.readTimeout = 20_000
        connection.requestMethod = "GET"
        connection.instanceFollowRedirects = true
        connection.setRequestProperty("Accept", "application/json")
        connection.setRequestProperty("User-Agent", "NexaMusic/7.0 Android (https://github.com/JPastore360/Nexa-Music)")
        return try {
            val status = connection.responseCode
            if (status !in 200..299) throw IllegalStateException("HTTP $status")
            connection.inputStream.bufferedReader().use { it.readText() }
        } finally {
            connection.disconnect()
        }
    }

    private fun extractDataArray(root: JSONObject): JSONArray? {
        val data = root.opt("data")
        return when (data) {
            is JSONArray -> data
            is JSONObject -> data.optJSONArray("tracks") ?: data.optJSONArray("results") ?: data.optJSONArray("data")
            else -> root.optJSONArray("results")
        }
    }

    private fun bestArtwork(artwork: JSONObject?): String {
        if (artwork == null) return ""
        return firstNonBlank(
            artwork.optString("1000x1000"), artwork.optString("_1000x1000"),
            artwork.optString("480x480"), artwork.optString("_480x480"),
            artwork.optString("150x150"), artwork.optString("_150x150")
        ).replace("http://", "https://")
    }

    private fun isStreamable(item: JSONObject): Boolean {
        val raw = if (item.has("is_streamable")) item.opt("is_streamable") else item.opt("isStreamable")
        return when (raw) {
            null, JSONObject.NULL -> true
            is Boolean -> raw
            is Number -> raw.toInt() != 0
            is String -> raw.equals("true", true) || raw == "1"
            else -> true
        }
    }

    private fun isStreamGated(item: JSONObject): Boolean {
        val raw = if (item.has("is_stream_gated")) item.opt("is_stream_gated") else item.opt("isStreamGated")
        return when (raw) {
            is Boolean -> raw
            is Number -> raw.toInt() != 0
            is String -> raw.equals("true", true) || raw == "1"
            else -> false
        }
    }

    private fun firstNonBlank(vararg values: String?): String =
        values.firstOrNull { !it.isNullOrBlank() }?.trim().orEmpty()

    private fun encodePath(value: String): String = URLEncoder.encode(value, "UTF-8").replace("+", "%20")
}
