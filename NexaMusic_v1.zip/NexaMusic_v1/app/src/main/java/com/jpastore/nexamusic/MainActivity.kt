package com.jpastore.nexamusic

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.delay
import java.util.Locale

private val Bg = Color(0xFF0B0D12)
private val Surface1 = Color(0xFF151922)
private val Surface2 = Color(0xFF1B202C)
private val Purple = Color(0xFF7C3AED)
private val Blue = Color(0xFF00C2FF)
private val Magenta = Color(0xFFE946FF)
private val TextPrimary = Color(0xFFF5F7FA)
private val TextSecondary = Color(0xFF9CA3AF)
private val Success = Color(0xFF49D49D)

private data class Track(
    val id: Int,
    val title: String,
    val artist: String,
    val mood: String,
    val rawRes: Int,
    val colors: List<Color>
)

private data class NavDestination(
    val label: String,
    val icon: ImageVector
)

private val tracks = listOf(
    Track(
        1,
        "Neon Horizon",
        "Nexa Sessions",
        "foco • eletrônico",
        R.raw.nexa_neon,
        listOf(Purple, Blue)
    ),
    Track(
        2,
        "Pulse Drive",
        "Nexa Sessions",
        "treino • energia",
        R.raw.nexa_pulse,
        listOf(Magenta, Purple)
    ),
    Track(
        3,
        "Quiet Orbit",
        "Nexa Sessions",
        "relaxar • ambiente",
        R.raw.nexa_orbit,
        listOf(Blue, Color(0xFF213A78))
    )
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Purple,
                    secondary = Blue,
                    tertiary = Magenta,
                    background = Bg,
                    surface = Surface1,
                    onPrimary = Color.White,
                    onBackground = TextPrimary,
                    onSurface = TextPrimary
                )
            ) {
                NexaMusicApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NexaMusicApp() {
    val context = LocalContext.current
    val exoPlayer = remember { ExoPlayer.Builder(context).build() }
    var selectedTab by remember { mutableIntStateOf(0) }
    var currentTrack by remember { mutableStateOf<Track?>(tracks.first()) }
    var showPlayer by remember { mutableStateOf(false) }
    val liked = remember { mutableStateListOf<Int>() }
    var isPlaying by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            exoPlayer.removeListener(listener)
            exoPlayer.release()
        }
    }

    fun loadAndPlay(track: Track) {
        currentTrack = track
        val uri = Uri.parse("android.resource://${context.packageName}/${track.rawRes}")
        exoPlayer.setMediaItem(MediaItem.fromUri(uri))
        exoPlayer.prepare()
        exoPlayer.playWhenReady = true
    }

    fun togglePlay() {
        val track = currentTrack ?: tracks.first()
        if (exoPlayer.mediaItemCount == 0) {
            loadAndPlay(track)
        } else if (exoPlayer.isPlaying) {
            exoPlayer.pause()
        } else {
            exoPlayer.play()
        }
    }

    fun skip(offset: Int) {
        val current = currentTrack ?: tracks.first()
        val idx = tracks.indexOfFirst { it.id == current.id }.coerceAtLeast(0)
        val next = (idx + offset + tracks.size) % tracks.size
        loadAndPlay(tracks[next])
    }

    val destinations = listOf(
        NavDestination("Início", Icons.Rounded.Home),
        NavDestination("Explorar", Icons.Rounded.Explore),
        NavDestination("Nexa AI", Icons.Rounded.AutoAwesome),
        NavDestination("Biblioteca", Icons.Rounded.LibraryMusic),
        NavDestination("Perfil", Icons.Rounded.Person)
    )

    Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                Column(
                    modifier = Modifier
                        .background(Bg)
                        .navigationBarsPadding()
                ) {
                    currentTrack?.let { track ->
                        MiniPlayer(
                            track = track,
                            isPlaying = isPlaying,
                            onOpen = { showPlayer = true },
                            onToggle = { togglePlay() },
                            onNext = { skip(1) }
                        )
                    }
                    NavigationBar(containerColor = Color(0xFF10141B)) {
                        destinations.forEachIndexed { index, item ->
                            val selected = selectedTab == index
                            NavigationBarItem(
                                selected = selected,
                                onClick = { selectedTab = index },
                                icon = {
                                    Icon(
                                        imageVector = item.icon,
                                        contentDescription = item.label
                                    )
                                },
                                label = {
                                    Text(item.label, fontSize = 10.sp, maxLines = 1)
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Blue,
                                    selectedTextColor = TextPrimary,
                                    indicatorColor = Purple.copy(alpha = 0.22f),
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary
                                )
                            )
                        }
                    }
                }
            }
        ) { padding ->
            when (selectedTab) {
                0 -> HomeScreen(
                    modifier = Modifier.padding(padding),
                    onPlay = { loadAndPlay(it) },
                    onOpenAI = { selectedTab = 2 }
                )
                1 -> ExploreScreen(
                    modifier = Modifier.padding(padding),
                    onPlay = { loadAndPlay(it) }
                )
                2 -> AiScreen(
                    modifier = Modifier.padding(padding),
                    onPlay = { loadAndPlay(it) }
                )
                3 -> LibraryScreen(
                    modifier = Modifier.padding(padding),
                    likedIds = liked,
                    onPlay = { loadAndPlay(it) }
                )
                else -> ProfileScreen(modifier = Modifier.padding(padding))
            }
        }
    }

    if (showPlayer && currentTrack != null) {
        ModalBottomSheet(
            onDismissRequest = { showPlayer = false },
            containerColor = Surface1,
            contentColor = TextPrimary
        ) {
            FullPlayer(
                track = currentTrack!!,
                exoPlayer = exoPlayer,
                isPlaying = isPlaying,
                isLiked = liked.contains(currentTrack!!.id),
                onClose = { showPlayer = false },
                onToggle = { togglePlay() },
                onNext = { skip(1) },
                onPrevious = { skip(-1) },
                onLike = {
                    val id = currentTrack!!.id
                    if (liked.contains(id)) liked.remove(id) else liked.add(id)
                }
            )
        }
    }
}

@Composable
private fun HomeScreen(
    modifier: Modifier = Modifier,
    onPlay: (Track) -> Unit,
    onOpenAI: () -> Unit
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Bg),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(22.dp)
    ) {
        item {
            Column {
                Text("NEXA MUSIC", color = Blue, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text("O que vamos ouvir?", color = TextPrimary, fontWeight = FontWeight.ExtraBold, fontSize = 29.sp)
                Text("Música que entende o seu momento.", color = TextSecondary, fontSize = 14.sp)
            }
        }

        item {
            AiHeroCard(onOpenAI = onOpenAI)
        }

        item {
            SectionHeader("Feito para você", "Seleções demonstrativas da Nexa")
        }

        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                items(tracks) { track ->
                    AlbumCard(track = track, onPlay = { onPlay(track) })
                }
            }
        }

        item {
            SectionHeader("Seu momento", "Toque e experimente o player")
        }

        items(tracks) { track ->
            TrackRow(track = track, onClick = { onPlay(track) })
        }

        item { Spacer(modifier = Modifier.height(8.dp)) }
    }
}

@Composable
private fun AiHeroCard(onOpenAI: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpenAI),
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        listOf(Purple.copy(alpha = 0.95f), Color(0xFF194DBE), Blue.copy(alpha = 0.85f))
                    )
                )
                .padding(22.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.AutoAwesome, null, tint = Color.White)
                    Spacer(Modifier.width(8.dp))
                    Text("Nexa AI", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                }
                Text(
                    "Diga como você está ou o que vai fazer. A Nexa monta a seleção para você.",
                    color = Color.White.copy(alpha = 0.92f),
                    fontSize = 15.sp
                )
                Button(
                    onClick = onOpenAI,
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF372071))
                ) {
                    Icon(Icons.Rounded.AutoAwesome, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Criar com IA", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun AlbumCard(track: Track, onPlay: () -> Unit) {
    Column(
        modifier = Modifier
            .width(164.dp)
            .clickable(onClick = onPlay)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .clip(RoundedCornerShape(22.dp))
                .background(Brush.linearGradient(track.colors)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Rounded.MusicNote,
                contentDescription = null,
                tint = Color.White.copy(alpha = 0.95f),
                modifier = Modifier.size(56.dp)
            )
            FilledIconButton(
                onClick = onPlay,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(10.dp),
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color.Black.copy(alpha = 0.72f))
            ) {
                Icon(Icons.Rounded.PlayArrow, "Tocar", tint = Color.White)
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(track.title, color = TextPrimary, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(track.mood, color = TextSecondary, fontSize = 12.sp, maxLines = 1)
    }
}

@Composable
private fun ExploreScreen(modifier: Modifier = Modifier, onPlay: (Track) -> Unit) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(query) {
        if (query.isBlank()) tracks else tracks.filter {
            (it.title + " " + it.artist + " " + it.mood).lowercase(Locale.getDefault())
                .contains(query.lowercase(Locale.getDefault()))
        }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("Explorar", color = TextPrimary, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
            Text("Busque por música, artista ou momento.", color = TextSecondary)
        }
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                leadingIcon = { Icon(Icons.Rounded.Search, null) },
                placeholder = { Text("Ex.: treino, foco, Nexa Sessions") },
                shape = RoundedCornerShape(18.dp)
            )
        }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(listOf("Treino", "Foco", "Relaxar", "Eletrônico")) { label ->
                    AssistChip(
                        onClick = { query = label },
                        label = { Text(label) },
                        leadingIcon = { Icon(Icons.Rounded.Headphones, null, Modifier.size(18.dp)) },
                        colors = AssistChipDefaults.assistChipColors(
                            containerColor = Surface2,
                            labelColor = TextPrimary,
                            leadingIconContentColor = Blue
                        )
                    )
                }
            }
        }
        item { SectionHeader("Resultados", "${filtered.size} faixa(s) nesta demonstração") }
        items(filtered) { track -> TrackRow(track = track, onClick = { onPlay(track) }) }
        if (filtered.isEmpty()) {
            item {
                Text("Nenhuma faixa encontrada nesta versão demonstrativa.", color = TextSecondary)
            }
        }
    }
}

@Composable
private fun AiScreen(modifier: Modifier = Modifier, onPlay: (Track) -> Unit) {
    var prompt by remember { mutableStateOf("") }
    var generated by remember { mutableStateOf<List<Track>>(emptyList()) }
    var explanation by remember { mutableStateOf("Conte para a Nexa o que você quer ouvir.") }

    fun generate() {
        val p = prompt.lowercase(Locale.getDefault())
        generated = when {
            listOf("treino", "academia", "energia", "correr").any { p.contains(it) } ->
                listOf(tracks[1], tracks[0], tracks[2])
            listOf("relax", "calma", "dormir", "tranquilo").any { p.contains(it) } ->
                listOf(tracks[2], tracks[0], tracks[1])
            listOf("foco", "estudar", "trabalho", "concentrar").any { p.contains(it) } ->
                listOf(tracks[0], tracks[2], tracks[1])
            else -> tracks.shuffled()
        }
        explanation = when {
            p.contains("treino") || p.contains("academia") -> "Comecei com mais energia e deixei o final mais leve."
            p.contains("relax") || p.contains("calma") -> "Priorizei uma entrada ambiente e transições mais suaves."
            p.contains("foco") || p.contains("estudar") -> "Priorizei faixas contínuas e menos agressivas para manter o foco."
            else -> "Misturei os três estilos disponíveis nesta v1 para variar a experiência."
        }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(50.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(Purple, Blue))),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Rounded.AutoAwesome, null, tint = Color.White)
                }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("Nexa AI", color = TextPrimary, fontSize = 29.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Sua DJ inteligente", color = Blue, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Surface1)
            ) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text(explanation, color = TextSecondary)
                    OutlinedTextField(
                        value = prompt,
                        onValueChange = { prompt = it },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2,
                        placeholder = { Text("Ex.: Quero músicas animadas para treinar por uma hora") },
                        trailingIcon = { Icon(Icons.Rounded.Mic, "Voz (em breve)", tint = TextSecondary) },
                        shape = RoundedCornerShape(18.dp)
                    )
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(listOf("Treino", "Foco", "Relaxar", "Me surpreenda")) { chip ->
                            AssistChip(
                                onClick = { prompt = chip },
                                label = { Text(chip) },
                                colors = AssistChipDefaults.assistChipColors(
                                    containerColor = Surface2,
                                    labelColor = TextPrimary
                                )
                            )
                        }
                    }
                    Button(
                        onClick = { generate() },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Purple)
                    ) {
                        Icon(Icons.Rounded.AutoAwesome, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Gerar seleção", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        if (generated.isNotEmpty()) {
            item { SectionHeader("A Nexa escolheu", "Toque em uma faixa para começar") }
            items(generated) { track -> TrackRow(track = track, onClick = { onPlay(track) }) }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Purple.copy(alpha = 0.12f))) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Info, null, tint = Blue)
                    Spacer(Modifier.width(10.dp))
                    Text(
                        "Nesta v1 a inteligência funciona localmente como demonstração. A arquitetura fica pronta para conectar uma IA real pelo backend sem expor chaves no APK.",
                        color = TextSecondary,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun LibraryScreen(
    modifier: Modifier = Modifier,
    likedIds: List<Int>,
    onPlay: (Track) -> Unit
) {
    val likedTracks = tracks.filter { likedIds.contains(it.id) }
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("Sua biblioteca", color = TextPrimary, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
            Text("Favoritos, playlists e histórico ficam aqui.", color = TextSecondary)
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                LibraryShortcut("Curtidas", "${likedTracks.size} músicas", Icons.Rounded.Favorite, Modifier.weight(1f))
                LibraryShortcut("Playlist", "Minha Nexa", Icons.Rounded.QueueMusic, Modifier.weight(1f))
            }
        }
        item {
            Button(
                onClick = { },
                enabled = false,
                colors = ButtonDefaults.buttonColors(disabledContainerColor = Surface2, disabledContentColor = TextSecondary)
            ) {
                Icon(Icons.Rounded.Add, null)
                Spacer(Modifier.width(8.dp))
                Text("Nova playlist — persistência na próxima etapa")
            }
        }
        item { SectionHeader("Músicas curtidas", if (likedTracks.isEmpty()) "Curta pelo player expandido" else "Seus favoritos locais") }
        if (likedTracks.isEmpty()) {
            item {
                Text("Abra uma música, expanda o player e toque no coração para adicioná-la aqui.", color = TextSecondary)
            }
        } else {
            items(likedTracks) { TrackRow(it, onClick = { onPlay(it) }) }
        }
    }
}

@Composable
private fun LibraryShortcut(title: String, subtitle: String, icon: ImageVector, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = Surface1),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Icon(icon, null, tint = Blue, modifier = Modifier.size(30.dp))
            Text(title, color = TextPrimary, fontWeight = FontWeight.Bold)
            Text(subtitle, color = TextSecondary, fontSize = 12.sp)
        }
    }
}

@Composable
private fun ProfileScreen(modifier: Modifier = Modifier) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("Perfil", color = TextPrimary, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
            Text("Preferências e informações do Nexa Music.", color = TextSecondary)
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Surface1), shape = RoundedCornerShape(22.dp)) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(54.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Purple, Blue))),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("JP", color = Color.White, fontWeight = FontWeight.ExtraBold)
                    }
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text("Nexa Music", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("Perfil local de demonstração", color = TextSecondary, fontSize = 12.sp)
                    }
                }
            }
        }
        item { MenuRow(Icons.Rounded.Settings, "Configurações", "Áudio, reprodução e aparência") }
        item { MenuRow(Icons.Rounded.Headphones, "Qualidade do áudio", "Automática — protótipo") }
        item { MenuRow(Icons.Rounded.LibraryMusic, "Conteúdo offline", "Disponível em etapa futura") }
        item { MenuRow(Icons.Rounded.Info, "Privacidade e termos", "Estrutura reservada para publicação") }
        item { Spacer(Modifier.height(20.dp)) }
        item {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                Text("Sobre o Nexa Music", color = TextSecondary, fontWeight = FontWeight.SemiBold)
                Text("Nexa Music", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("Criado por J. Pastore", color = Blue, fontWeight = FontWeight.Bold)
                Text("Powered by Nexa AI", color = Purple)
                Text("© 2026 • Versão 1.0.0", color = TextSecondary, fontSize = 12.sp)
            }
        }
        item { Spacer(Modifier.height(12.dp)) }
    }
}

@Composable
private fun MenuRow(icon: ImageVector, title: String, subtitle: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Surface1), shape = RoundedCornerShape(18.dp)) {
        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, null, tint = Blue)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = TextSecondary, fontSize = 12.sp)
            }
            Icon(Icons.Rounded.ChevronRight, null, tint = TextSecondary)
        }
    }
}

@Composable
private fun TrackRow(track: Track, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(58.dp)
                .clip(RoundedCornerShape(15.dp))
                .background(Brush.linearGradient(track.colors)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Rounded.MusicNote, null, tint = Color.White)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(track.title, color = TextPrimary, fontWeight = FontWeight.Bold, maxLines = 1)
            Text("${track.artist} • ${track.mood}", color = TextSecondary, fontSize = 12.sp, maxLines = 1)
        }
        IconButton(onClick = onClick) {
            Icon(Icons.Rounded.PlayArrow, "Tocar ${track.title}", tint = Blue)
        }
    }
}

@Composable
private fun SectionHeader(title: String, subtitle: String) {
    Column {
        Text(title, color = TextPrimary, fontWeight = FontWeight.ExtraBold, fontSize = 21.sp)
        Text(subtitle, color = TextSecondary, fontSize = 13.sp)
    }
}

@Composable
private fun MiniPlayer(
    track: Track,
    isPlaying: Boolean,
    onOpen: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Surface2)
            .clickable(onClick = onOpen)
            .padding(horizontal = 12.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Brush.linearGradient(track.colors)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Rounded.MusicNote, null, tint = Color.White, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(track.title, color = TextPrimary, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(track.artist, color = TextSecondary, fontSize = 11.sp, maxLines = 1)
        }
        IconButton(onClick = onToggle) {
            Icon(if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, "Play/Pause", tint = TextPrimary)
        }
        IconButton(onClick = onNext) {
            Icon(Icons.Rounded.SkipNext, "Próxima", tint = TextPrimary)
        }
    }
}

@Composable
private fun FullPlayer(
    track: Track,
    exoPlayer: ExoPlayer,
    isPlaying: Boolean,
    isLiked: Boolean,
    onClose: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onLike: () -> Unit
) {
    var progress by remember(track.id) { mutableFloatStateOf(0f) }
    var duration by remember(track.id) { mutableFloatStateOf(1f) }

    LaunchedEffect(track.id, isPlaying) {
        while (true) {
            val d = exoPlayer.duration.takeIf { it > 0 } ?: 1L
            duration = d.toFloat()
            progress = exoPlayer.currentPosition.coerceIn(0L, d).toFloat()
            delay(400)
        }
    }

    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp)
            .padding(bottom = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("TOCANDO AGORA", color = Blue, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                Text("Nexa Music", color = TextSecondary, fontSize = 12.sp)
            }
            IconButton(onClick = onClose) { Icon(Icons.Rounded.Close, "Fechar", tint = TextPrimary) }
        }
        Spacer(Modifier.height(18.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth(0.84f)
                .aspectRatio(1f)
                .clip(RoundedCornerShape(34.dp))
                .background(Brush.linearGradient(track.colors)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Rounded.MusicNote, null, tint = Color.White, modifier = Modifier.size(92.dp))
        }
        Spacer(Modifier.height(24.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(track.title, color = TextPrimary, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                Text(track.artist, color = TextSecondary, fontSize = 14.sp)
            }
            IconButton(onClick = onLike) {
                Icon(
                    if (isLiked) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                    "Curtir",
                    tint = if (isLiked) Magenta else TextSecondary
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        Slider(
            value = progress.coerceIn(0f, duration.coerceAtLeast(1f)),
            onValueChange = { progress = it },
            onValueChangeFinished = { exoPlayer.seekTo(progress.toLong()) },
            valueRange = 0f..duration.coerceAtLeast(1f)
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatMs(progress.toLong()), color = TextSecondary, fontSize = 11.sp)
            Text(formatMs(duration.toLong()), color = TextSecondary, fontSize = 11.sp)
        }
        Spacer(Modifier.height(12.dp))
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { }) { Icon(Icons.Rounded.Shuffle, "Aleatório", tint = TextSecondary) }
            IconButton(onClick = onPrevious, modifier = Modifier.size(56.dp)) {
                Icon(Icons.Rounded.SkipPrevious, "Anterior", tint = TextPrimary, modifier = Modifier.size(38.dp))
            }
            FilledIconButton(
                onClick = onToggle,
                modifier = Modifier.size(72.dp),
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = Purple, contentColor = Color.White)
            ) {
                Icon(
                    if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    "Play/Pause",
                    modifier = Modifier.size(38.dp)
                )
            }
            IconButton(onClick = onNext, modifier = Modifier.size(56.dp)) {
                Icon(Icons.Rounded.SkipNext, "Próxima", tint = TextPrimary, modifier = Modifier.size(38.dp))
            }
            IconButton(onClick = { }) { Icon(Icons.Rounded.QueueMusic, "Fila", tint = TextSecondary) }
        }
    }
}

private fun formatMs(ms: Long): String {
    val totalSeconds = (ms / 1000).coerceAtLeast(0)
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%d:%02d".format(minutes, seconds)
}
