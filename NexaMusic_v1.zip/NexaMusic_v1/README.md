# Nexa Music v1

Nexa Music é um protótipo Android de streaming musical com identidade própria e uma área de IA musical.

## O que já funciona
- Interface premium escura (grafite + roxo elétrico + azul neon)
- Início, Explorar, Nexa AI, Biblioteca e Perfil
- Mini player e player expandido
- Play/pause, próxima/anterior e barra de progresso
- 3 faixas demonstrativas locais geradas para o protótipo
- Busca por músicas, artistas e tags
- Nexa AI local demonstrativa: interpreta pedidos simples e monta uma seleção
- Créditos apenas no final da tela Perfil/Sobre
- GitHub Actions para gerar APK automaticamente

## Identidade
- App: **Nexa Music**
- Pacote: `com.jpastore.nexamusic`
- Créditos: **Criado por J. Pastore**

## Compilar pelo GitHub no celular
1. Crie um repositório vazio no GitHub, por exemplo `NexaMusic`.
2. Envie todo o conteúdo deste projeto para a raiz do repositório.
3. Abra a aba **Actions**.
4. Execute **Build Nexa Music APK** (ou faça um novo commit na branch main/master).
5. Ao finalizar, abra o job e baixe o artifact **NexaMusic-v1-debug**.

## Próximas integrações previstas
- Backend e login
- Catálogo musical autorizado/licenciado
- IA real via API protegida no backend
- Recomendações personalizadas por histórico
- Playlists persistentes, favoritos e downloads offline
- MediaSession/controles completos na tela bloqueada

> Importante: este protótipo não usa catálogo do Spotify nem redistribui músicas protegidas. As faixas incluídas são sons demonstrativos gerados para o projeto.
