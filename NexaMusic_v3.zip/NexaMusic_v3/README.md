# Nexa Music v3

Versão 3.0.0 do Nexa Music.

## O que mudou
- Busca online real por música, artista e álbum.
- Capas e álbuns reais na tela inicial.
- Detalhes do álbum com lista de faixas disponíveis.
- Reprodução por streaming das prévias disponibilizadas pelo catálogo.
- Nexa AI usa o catálogo online para montar seleções.
- Favoritos, histórico e playlists passam a salvar os metadados das músicas.
- Player em segundo plano e controles do sistema mantidos.

## Observação sobre catálogo
A busca e os metadados desta versão usam o iTunes Search API. O endpoint público fornece metadados, capas e URLs de prévia; ele não equivale a uma licença de streaming integral do catálogo. Para músicas completas em uma versão pública, é necessário integrar um provedor/licenciamento apropriado.
