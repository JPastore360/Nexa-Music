package com.jpastore.nexamusic

import android.Manifest
import android.content.ComponentName
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.max

private val Bg = Color(0xFF0B0D12)
private val Surface1 = Color(0xFF151922)
private val Surface2 = Color(0xFF1B202C)
private val Purple = Color(0xFF7C3AED)
private val Blue = Color(0xFF00C2FF)
private val Magenta = Color(0xFFE946FF)
private val TextPrimary = Color(0xFFF5F7FA)
private val TextSecondary = Color(0xFF9CA3AF)
private val Success = Color(0xFF49D49D)
private val Danger = Color(0xFFFF6B7A)

private data class NavDestination(val label: String, val icon: ImageVector)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2001)
        }

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Purple,
                    secondary = Blue,
                    tertiary = Magenta,
                    background = Bg,
                    surface = Surface1,
                    onPrimary = Color.White,
                    onBackground = TextPrimary,
                    onSurface = TextPrimary
                )
            ) { NexaMusicApp() }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NexaMusicApp() {
    val context = LocalContext.current
    val store = remember { LibraryStore(context.applicationContext) }
    var liked by remember { mutableStateOf(store.getLiked()) }
    var history by remember { mutableStateOf(store.getHistory()) }
    var playlists by remember { mutableStateOf(store.getPlaylists()) }

    var selectedTab by remember { mutableIntStateOf(0) }
    var controller by remember { mutableStateOf<MediaController?>(null) }
    var currentTrack by remember { mutableStateOf<Track?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var shuffleEnabled by remember { mutableStateOf(false) }
    var repeatMode by remember { mutableIntStateOf(Player.REPEAT_MODE_OFF) }
    var showPlayer by remember { mutableStateOf(false) }
    var showPlaylistDialog by remember { mutableStateOf(false) }
    var albumSeed by remember { mutableStateOf<Track?>(null) }

    DisposableEffect(Unit) {
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener(
            {
                runCatching { future.get() }.onSuccess { mediaController ->
                    controller = mediaController
                    isPlaying = mediaController.isPlaying
                    shuffleEnabled = mediaController.shuffleModeEnabled
                    repeatMode = mediaController.repeatMode
                }
            },
            ContextCompat.getMainExecutor(context)
        )
        onDispose {
            MediaController.releaseFuture(future)
            controller = null
        }
    }

    DisposableEffect(controller) {
        val c = controller
        if (c == null) {
            onDispose { }
        } else {
            val listener = object : Player.Listener {
                override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
                override fun onShuffleModeEnabledChanged(enabled: Boolean) { shuffleEnabled = enabled }
                override fun onRepeatModeChanged(mode: Int) { repeatMode = mode }
                override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                    val track = mediaItem?.let(::trackFromMediaItem)
                    if (track != null) {
                        currentTrack = track
                        history = store.addHistory(track)
                    }
                }
            }
            c.addListener(listener)
            onDispose { c.removeListener(listener) }
        }
    }

    fun playQueue(queue: List<Track>, selected: Track) {
        val c = controller ?: return
        if (queue.isEmpty()) return
        val index = queue.indexOfFirst { it.id == selected.id }.coerceAtLeast(0)
        c.setMediaItems(queue.map { it.toMediaItem() }, index, 0L)
        c.prepare()
        c.play()
        currentTrack = selected
        history = store.addHistory(selected)
    }

    fun playTrack(track: Track) = playQueue(listOf(track), track)

    fun togglePlay() {
        val c = controller ?: return
        if (c.mediaItemCount == 0) return
        if (c.isPlaying) c.pause() else c.play()
    }

    fun next() {
        controller?.let { c ->
            if (c.hasNextMediaItem()) c.seekToNextMediaItem()
            c.play()
        }
    }

    fun previous() {
        controller?.let { c ->
            if (c.currentPosition > 4_000) c.seekTo(0)
            else if (c.hasPreviousMediaItem()) c.seekToPreviousMediaItem()
            c.play()
        }
    }

    fun toggleLiked(track: Track) { liked = store.toggleLiked(track) }
    fun createPlaylist(name: String) { playlists = store.createPlaylist(name) }
    fun addToPlaylist(name: String, track: Track) { playlists = store.addToPlaylist(name, track) }
    fun createPlaylistAndAdd(name: String, track: Track) {
        store.createPlaylist(name)
        playlists = store.addToPlaylist(name.trim(), track)
    }
    fun removeFromPlaylist(name: String, track: Track) { playlists = store.removeFromPlaylist(name, track) }
    fun deletePlaylist(name: String) { playlists = store.deletePlaylist(name) }

    val destinations = listOf(
        NavDestination("Início", Icons.Rounded.Home),
        NavDestination("Explorar", Icons.Rounded.Explore),
        NavDestination("Nexa AI", Icons.Rounded.AutoAwesome),
        NavDestination("Biblioteca", Icons.Rounded.LibraryMusic),
        NavDestination("Perfil", Icons.Rounded.Person)
    )

    Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                Column(modifier = Modifier.background(Bg).navigationBarsPadding()) {
                    currentTrack?.let { track ->
                        MiniPlayer(track, isPlaying, { showPlayer = true }, ::togglePlay, ::next)
                    }
                    NavigationBar(containerColor = Color(0xFF10141B)) {
                        destinations.forEachIndexed { index, item ->
                            val selected = selectedTab == index
                            NavigationBarItem(
                                selected = selected,
                                onClick = { selectedTab = index },
                                icon = { Icon(item.icon, item.label) },
                                label = { Text(item.label, fontSize = 10.sp, maxLines = 1) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Blue,
                                    selectedTextColor = TextPrimary,
                                    indicatorColor = Purple.copy(alpha = 0.22f),
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary
                                )
                            )
                        }
                    }
                }
            }
        ) { padding ->
            when (selectedTab) {
                0 -> HomeScreen(
                    modifier = Modifier.padding(padding),
                    onPlayQueue = ::playQueue,
                    onOpenAlbum = { albumSeed = it },
                    onOpenAI = { selectedTab = 2 }
                )
                1 -> ExploreScreen(
                    modifier = Modifier.padding(padding),
                    onPlayQueue = ::playQueue,
                    onOpenAlbum = { albumSeed = it }
                )
                2 -> AiScreen(
                    modifier = Modifier.padding(padding),
                    onPlayQueue = { queue -> if (queue.isNotEmpty()) playQueue(queue, queue.first()) }
                )
                3 -> LibraryScreen(
                    modifier = Modifier.padding(padding),
                    liked = liked,
                    history = history,
                    playlists = playlists,
                    onPlay = ::playTrack,
                    onCreatePlaylist = ::createPlaylist,
                    onRemoveFromPlaylist = ::removeFromPlaylist,
                    onDeletePlaylist = ::deletePlaylist
                )
                else -> ProfileScreen(modifier = Modifier.padding(padding))
            }
        }
    }

    if (showPlayer && currentTrack != null) {
        ModalBottomSheet(
            onDismissRequest = { showPlayer = false },
            containerColor = Surface1,
            contentColor = TextPrimary
        ) {
            FullPlayer(
                track = currentTrack!!,
                controller = controller,
                isPlaying = isPlaying,
                isLiked = liked.any { it.id == currentTrack!!.id },
                shuffleEnabled = shuffleEnabled,
                repeatMode = repeatMode,
                onToggle = ::togglePlay,
                onNext = ::next,
                onPrevious = ::previous,
                onLike = { toggleLiked(currentTrack!!) },
                onPlaylist = { showPlaylistDialog = true },
                onShuffle = {
                    controller?.let {
                        it.shuffleModeEnabled = !it.shuffleModeEnabled
                        shuffleEnabled = it.shuffleModeEnabled
                    }
                },
                onRepeat = {
                    controller?.let {
                        val nextMode = when (it.repeatMode) {
                            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                            else -> Player.REPEAT_MODE_OFF
                        }
                        it.repeatMode = nextMode
                        repeatMode = nextMode
                    }
                }
            )
        }
    }

    if (showPlaylistDialog && currentTrack != null) {
        AddToPlaylistDialog(
            playlistNames = playlists.keys.toList(),
            onDismiss = { showPlaylistDialog = false },
            onAdd = { name -> addToPlaylist(name, currentTrack!!); showPlaylistDialog = false },
            onCreateAndAdd = { name -> createPlaylistAndAdd(name, currentTrack!!); showPlaylistDialog = false }
        )
    }

    albumSeed?.let { seed ->
        AlbumDetailSheet(
            seed = seed,
            onDismiss = { albumSeed = null },
            onPlayQueue = { queue, selected -> playQueue(queue, selected) }
        )
    }
}

private fun trackFromMediaItem(item: MediaItem): Track? {
    val uri = item.localConfiguration?.uri?.toString().orEmpty()
    if (uri.isBlank()) return null
    return Track(
        id = item.mediaId,
        title = item.mediaMetadata.title?.toString().orEmpty().ifBlank { "Música" },
        artist = item.mediaMetadata.artist?.toString().orEmpty().ifBlank { "Artista" },
        album = item.mediaMetadata.albumTitle?.toString().orEmpty().ifBlank { "Álbum" },
        previewUrl = uri,
        artworkUrl = item.mediaMetadata.artworkUri?.toString().orEmpty(),
        genre = "",
        collectionId = ""
    )
}

@Composable
private fun HomeScreen(
    modifier: Modifier = Modifier,
    onPlayQueue: (List<Track>, Track) -> Unit,
    onOpenAlbum: (Track) -> Unit,
    onOpenAI: () -> Unit
) {
    var tracks by remember { mutableStateOf<List<Track>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var reloadToken by remember { mutableIntStateOf(0) }

    LaunchedEffect(reloadToken) {
        loading = true
        error = null
        runCatching { CatalogRepository.homeTracks() }
            .onSuccess { tracks = it }
            .onFailure { error = "Não foi possível carregar o catálogo. Verifique a internet." }
        loading = false
    }

    val albums = remember(tracks) { CatalogRepository.albumsFrom(tracks).take(14) }

    LazyColumn(
        modifier = modifier.fillMaxSize().background(Bg),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(22.dp)
    ) {
        item {
            Column {
                Text("NEXA MUSIC", color = Blue, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text("O que vamos ouvir?", color = TextPrimary, fontWeight = FontWeight.ExtraBold, fontSize = 29.sp)
                Text("Descubra músicas, artistas e álbuns reais.", color = TextSecondary, fontSize = 14.sp)
            }
        }
        item { AiHeroCard(onOpenAI) }

        if (loading) {
            item { LoadingBlock("Carregando álbuns e músicas…") }
        } else if (error != null) {
            item {
                ErrorBlock(error!!, onRetry = { reloadToken++ })
            }
        } else {
            item { SectionHeader("Álbuns para descobrir", "Capas e artistas carregados do catálogo") }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    items(albums, key = { it.collectionId }) { album ->
                        AlbumCard(album = album, onOpen = { onOpenAlbum(album.seedTrack) })
                    }
                }
            }
            item { SectionHeader("Ouça agora", "Toque para ouvir a prévia disponível") }
            items(tracks.take(16), key = { it.id }) { track ->
                TrackRow(track = track, onClick = { onPlayQueue(tracks, track) })
            }
        }
        item { Spacer(Modifier.height(8.dp)) }
    }
}

@Composable
private fun AiHeroCard(onOpenAI: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onOpenAI),
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Box(
            modifier = Modifier.fillMaxWidth()
                .background(Brush.linearGradient(listOf(Purple, Color(0xFF194DBE), Blue)))
                .padding(22.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.AutoAwesome, null, tint = Color.White)
                    Spacer(Modifier.width(8.dp))
                    Text("Nexa AI", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                }
                Text("Diga o que quer ouvir e a Nexa busca uma seleção no catálogo.", color = Color.White.copy(alpha = 0.92f), fontSize = 15.sp)
                Button(
                    onClick = onOpenAI,
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF372071))
                ) {
                    Icon(Icons.Rounded.AutoAwesome, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Criar com IA", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun AlbumCard(album: AlbumSummary, onOpen: () -> Unit) {
    Column(modifier = Modifier.width(160.dp).clickable(onClick = onOpen)) {
        Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Surface1)) {
            AsyncImage(
                model = album.artworkUrl,
                contentDescription = "Capa de ${album.title}",
                modifier = Modifier.fillMaxWidth().aspectRatio(1f)
            )
        }
        Spacer(Modifier.height(9.dp))
        Text(album.title, color = TextPrimary, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(album.artist, color = TextSecondary, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun ExploreScreen(
    modifier: Modifier = Modifier,
    onPlayQueue: (List<Track>, Track) -> Unit,
    onOpenAlbum: (Track) -> Unit
) {
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Track>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(query) {
        val clean = query.trim()
        if (clean.length < 2) {
            results = emptyList(); loading = false; error = null; return@LaunchedEffect
        }
        delay(450)
        loading = true
        error = null
        runCatching { CatalogRepository.searchSongs(clean, 35) }
            .onSuccess { results = it }
            .onFailure { error = "Falha na busca. Tente novamente." }
        loading = false
    }

    val albums = remember(results) { CatalogRepository.albumsFrom(results).take(10) }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("Explorar", color = TextPrimary, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
            Text("Busque por música, artista ou álbum.", color = TextSecondary)
        }
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                leadingIcon = { Icon(Icons.Rounded.Search, null) },
                placeholder = { Text("Ex.: Ana Castela, Coldplay, rock…") },
                shape = RoundedCornerShape(18.dp)
            )
        }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(listOf("Sertanejo", "Pop", "Rock", "MPB", "Pagode")) { label ->
                    AssistChip(onClick = { query = label }, label = { Text(label) }, leadingIcon = { Icon(Icons.Rounded.Headphones, null, Modifier.size(18.dp)) })
                }
            }
        }
        when {
            loading -> item { LoadingBlock("Buscando no catálogo…") }
            error != null -> item { ErrorBlock(error!!, onRetry = { query = query + " " }) }
            query.trim().length < 2 -> item { HintBlock("Digite pelo menos 2 letras para pesquisar.") }
            results.isEmpty() -> item { HintBlock("Nenhum resultado encontrado para “${query.trim()}”.") }
            else -> {
                if (albums.isNotEmpty()) {
                    item { SectionHeader("Álbuns", "Resultados relacionados à sua busca") }
                    item {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            items(albums, key = { it.collectionId }) { album ->
                                AlbumCard(album, onOpen = { onOpenAlbum(album.seedTrack) })
                            }
                        }
                    }
                }
                item { SectionHeader("Músicas", "${results.size} resultados") }
                items(results, key = { it.id }) { track -> TrackRow(track, onClick = { onPlayQueue(results, track) }) }
            }
        }
    }
}

@Composable
private fun AiScreen(modifier: Modifier = Modifier, onPlayQueue: (List<Track>) -> Unit) {
    val scope = rememberCoroutineScope()
    var prompt by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Descreva seu momento e a Nexa cria uma fila usando o catálogo.") }
    var results by remember { mutableStateOf<List<Track>>(emptyList()) }

    fun translatePrompt(text: String): String {
        val p = text.lowercase(Locale.getDefault())
        return when {
            "treino" in p || "academia" in p -> "workout hits"
            "relax" in p || "calma" in p -> "acoustic chill"
            "foco" in p || "estudar" in p || "trabalho" in p -> "focus instrumental"
            "sertanejo" in p -> "sertanejo"
            "pagode" in p -> "pagode"
            "rock" in p -> "rock"
            "românt" in p || "amor" in p -> "romantic"
            else -> text.trim()
        }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("Nexa AI", color = TextPrimary, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
            Text("Peça uma seleção em linguagem natural.", color = TextSecondary)
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Surface1), shape = RoundedCornerShape(24.dp)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = prompt,
                        onValueChange = { prompt = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Ex.: Quero sertanejo animado para viajar") },
                        minLines = 3,
                        shape = RoundedCornerShape(18.dp)
                    )
                    Button(
                        onClick = {
                            if (prompt.trim().length < 2 || loading) return@Button
                            scope.launch {
                                loading = true
                                val query = translatePrompt(prompt)
                                runCatching { CatalogRepository.searchSongs(query, 30) }
                                    .onSuccess {
                                        results = it
                                        message = if (it.isEmpty()) "Não encontrei uma seleção para esse pedido." else "Seleção criada com ${it.size} faixas."
                                    }
                                    .onFailure { message = "Não consegui acessar o catálogo agora." }
                                loading = false
                            }
                        },
                        enabled = !loading && prompt.trim().length >= 2,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (loading) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                        else Icon(Icons.Rounded.AutoAwesome, null)
                        Spacer(Modifier.width(8.dp))
                        Text(if (loading) "Criando…" else "Criar seleção")
                    }
                    Text(message, color = TextSecondary, fontSize = 13.sp)
                }
            }
        }
        if (results.isNotEmpty()) {
            item {
                Button(onClick = { onPlayQueue(results) }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.PlayArrow, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Tocar seleção")
                }
            }
            items(results.take(12), key = { it.id }) { track -> TrackRow(track, onClick = { onPlayQueue(results.dropWhile { it.id != track.id }) }) }
        }
    }
}

@Composable
private fun LibraryScreen(
    modifier: Modifier = Modifier,
    liked: List<Track>,
    history: List<Track>,
    playlists: Map<String, List<Track>>,
    onPlay: (Track) -> Unit,
    onCreatePlaylist: (String) -> Unit,
    onRemoveFromPlaylist: (String, Track) -> Unit,
    onDeletePlaylist: (String) -> Unit
) {
    var showCreate by remember { mutableStateOf(false) }
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("Biblioteca", color = TextPrimary, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Curtidas, histórico e playlists.", color = TextSecondary)
                }
                FilledIconButton(onClick = { showCreate = true }) { Icon(Icons.Rounded.Add, "Nova playlist") }
            }
        }
        item { SectionHeader("Curtidas", "${liked.size} músicas") }
        if (liked.isEmpty()) item { HintBlock("Curta uma música no player para ela aparecer aqui.") }
        else items(liked.take(10), key = { "liked-${it.id}" }) { TrackRow(it, onClick = { onPlay(it) }) }

        item { SectionHeader("Histórico", "Ouvidas recentemente") }
        if (history.isEmpty()) item { HintBlock("Seu histórico aparece depois que você reproduz músicas.") }
        else items(history.take(10), key = { "history-${it.id}" }) { TrackRow(it, onClick = { onPlay(it) }) }

        item { SectionHeader("Playlists", "${playlists.size} criadas") }
        if (playlists.isEmpty()) item { HintBlock("Crie sua primeira playlist pelo botão +.") }
        else {
            playlists.forEach { (name, tracks) ->
                item(key = "pl-$name") {
                    Card(colors = CardDefaults.cardColors(containerColor = Surface1), shape = RoundedCornerShape(20.dp)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.QueueMusic, null, tint = Blue)
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(name, color = TextPrimary, fontWeight = FontWeight.Bold)
                                    Text("${tracks.size} músicas", color = TextSecondary, fontSize = 12.sp)
                                }
                                IconButton(onClick = { onDeletePlaylist(name) }) { Icon(Icons.Rounded.Delete, "Excluir") }
                            }
                            tracks.take(5).forEach { track ->
                                Row(
                                    Modifier.fillMaxWidth().clickable { onPlay(track) }.padding(vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    AsyncImage(track.artworkUrl, null, Modifier.size(40.dp).clip(RoundedCornerShape(10.dp)))
                                    Spacer(Modifier.width(10.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(track.title, color = TextPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text(track.artist, color = TextSecondary, fontSize = 12.sp, maxLines = 1)
                                    }
                                    IconButton(onClick = { onRemoveFromPlaylist(name, track) }) { Icon(Icons.Rounded.Delete, "Remover") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCreate) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showCreate = false },
            title = { Text("Nova playlist") },
            text = { OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true, placeholder = { Text("Nome da playlist") }) },
            confirmButton = { TextButton(onClick = { onCreatePlaylist(name); showCreate = false }, enabled = name.isNotBlank()) { Text("Criar") } },
            dismissButton = { TextButton(onClick = { showCreate = false }) { Text("Cancelar") } }
        )
    }
}

@Composable
private fun ProfileScreen(modifier: Modifier = Modifier) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("Perfil", color = TextPrimary, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
            Text("Preferências e informações do Nexa Music.", color = TextSecondary)
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Surface1), shape = RoundedCornerShape(22.dp)) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(54.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Purple, Blue))), contentAlignment = Alignment.Center) {
                        Text("JP", color = Color.White, fontWeight = FontWeight.ExtraBold)
                    }
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text("Nexa Music", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("Catálogo online conectado", color = Success, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
        item { MenuRow(Icons.Rounded.Settings, "Configurações", "Reprodução e aparência") }
        item { MenuRow(Icons.Rounded.Headphones, "Segundo plano", "Controles do sistema e tela bloqueada") }
        item { MenuRow(Icons.Rounded.Search, "Catálogo", "Busca real por música, artista e álbum") }
        item { MenuRow(Icons.Rounded.Info, "Sobre as músicas", "Nesta versão, a reprodução usa prévias disponibilizadas pelo catálogo") }
        item { Spacer(Modifier.height(20.dp)) }
        item {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("Sobre o Nexa Music", color = TextSecondary, fontWeight = FontWeight.SemiBold)
                Text("Nexa Music", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("Criado por J. Pastore", color = Blue, fontWeight = FontWeight.Bold)
                Text("Powered by Nexa AI", color = Purple)
                Text("© 2026 • Versão 3.0.0", color = TextSecondary, fontSize = 12.sp)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AlbumDetailSheet(seed: Track, onDismiss: () -> Unit, onPlayQueue: (List<Track>, Track) -> Unit) {
    var tracks by remember(seed.collectionId) { mutableStateOf<List<Track>>(emptyList()) }
    var loading by remember(seed.collectionId) { mutableStateOf(true) }
    var error by remember(seed.collectionId) { mutableStateOf<String?>(null) }

    LaunchedEffect(seed.collectionId) {
        loading = true
        runCatching { CatalogRepository.albumTracks(seed.collectionId) }
            .onSuccess { tracks = if (it.isEmpty()) listOf(seed) else it }
            .onFailure { error = "Não foi possível carregar as faixas do álbum."; tracks = listOf(seed) }
        loading = false
    }

    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = Surface1, contentColor = TextPrimary) {
        LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AsyncImage(seed.artworkUrl, "Capa de ${seed.album}", Modifier.size(110.dp).clip(RoundedCornerShape(18.dp)))
                    Spacer(Modifier.width(16.dp))
                    Column(Modifier.weight(1f)) {
                        Text(seed.album, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                        Text(seed.artist, color = TextSecondary)
                        if (seed.genre.isNotBlank()) Text(seed.genre, color = Blue, fontSize = 12.sp)
                    }
                }
            }
            if (loading) item { LoadingBlock("Carregando álbum…") }
            else {
                error?.let { item { Text(it, color = Danger, fontSize = 12.sp) } }
                items(tracks, key = { "album-${it.id}" }) { track ->
                    TrackRow(track, onClick = { onPlayQueue(tracks, track) })
                }
            }
            item { Spacer(Modifier.height(20.dp)) }
        }
    }
}

@Composable
private fun FullPlayer(
    track: Track,
    controller: MediaController?,
    isPlaying: Boolean,
    isLiked: Boolean,
    shuffleEnabled: Boolean,
    repeatMode: Int,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onLike: () -> Unit,
    onPlaylist: () -> Unit,
    onShuffle: () -> Unit,
    onRepeat: () -> Unit
) {
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(30_000L) }
    LaunchedEffect(controller, track.id) {
        while (true) {
            position = controller?.currentPosition?.coerceAtLeast(0L) ?: 0L
            duration = max(controller?.duration ?: 30_000L, 1L)
            delay(500)
        }
    }

    Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        AsyncImage(track.artworkUrl, "Capa", Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(28.dp)))
        Spacer(Modifier.height(20.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(track.title, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(track.artist, color = TextSecondary, fontSize = 16.sp)
                Text(track.album, color = Blue, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            IconButton(onClick = onLike) { Icon(if (isLiked) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, "Curtir", tint = if (isLiked) Magenta else TextSecondary) }
        }
        Slider(
            value = (position.toFloat() / duration.toFloat()).coerceIn(0f, 1f),
            onValueChange = { controller?.seekTo((duration * it).toLong()) },
            modifier = Modifier.fillMaxWidth()
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onShuffle) { Icon(Icons.Rounded.Shuffle, "Aleatório", tint = if (shuffleEnabled) Blue else TextSecondary) }
            IconButton(onClick = onPrevious) { Icon(Icons.Rounded.SkipPrevious, "Anterior", Modifier.size(36.dp)) }
            FilledIconButton(onClick = onToggle, modifier = Modifier.size(68.dp), colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color.White, contentColor = Color.Black)) {
                Icon(if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, "Play/Pause", Modifier.size(38.dp))
            }
            IconButton(onClick = onNext) { Icon(Icons.Rounded.SkipNext, "Próxima", Modifier.size(36.dp)) }
            IconButton(onClick = onRepeat) { Icon(if (repeatMode == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat, "Repetir", tint = if (repeatMode != Player.REPEAT_MODE_OFF) Blue else TextSecondary) }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = onPlaylist) {
            Icon(Icons.Rounded.PlaylistAdd, null)
            Spacer(Modifier.width(8.dp))
            Text("Adicionar à playlist")
        }
        Spacer(Modifier.height(10.dp))
        Text("Reprodução desta versão usa a prévia disponibilizada pelo catálogo.", color = TextSecondary, fontSize = 11.sp)
        Spacer(Modifier.height(22.dp))
    }
}

@Composable
private fun MiniPlayer(track: Track, isPlaying: Boolean, onOpen: () -> Unit, onToggle: () -> Unit, onNext: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().background(Surface2).clickable(onClick = onOpen).padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AsyncImage(track.artworkUrl, null, Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(track.title, color = TextPrimary, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(track.artist, color = TextSecondary, fontSize = 12.sp, maxLines = 1)
        }
        IconButton(onClick = onToggle) { Icon(if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, "Play/Pause") }
        IconButton(onClick = onNext) { Icon(Icons.Rounded.SkipNext, "Próxima") }
    }
}

@Composable
private fun TrackRow(track: Track, onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Card(shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = Surface1)) {
            if (track.artworkUrl.isNotBlank()) AsyncImage(track.artworkUrl, null, Modifier.size(58.dp))
            else Box(Modifier.size(58.dp), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.MusicNote, null, tint = Blue) }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(track.title, color = TextPrimary, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${track.artist} • ${track.album}", color = TextSecondary, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Icon(Icons.Rounded.PlayArrow, "Tocar", tint = Blue)
    }
}

@Composable
private fun SectionHeader(title: String, subtitle: String) {
    Column {
        Text(title, color = TextPrimary, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
        Text(subtitle, color = TextSecondary, fontSize = 13.sp)
    }
}

@Composable
private fun LoadingBlock(text: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 22.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
        CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp)
        Spacer(Modifier.width(10.dp))
        Text(text, color = TextSecondary)
    }
}

@Composable
private fun ErrorBlock(text: String, onRetry: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Surface1), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(text, color = Danger, modifier = Modifier.weight(1f), fontSize = 13.sp)
            IconButton(onClick = onRetry) { Icon(Icons.Rounded.Refresh, "Tentar novamente") }
        }
    }
}

@Composable
private fun HintBlock(text: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Surface1), shape = RoundedCornerShape(16.dp)) {
        Text(text, color = TextSecondary, fontSize = 13.sp, modifier = Modifier.fillMaxWidth().padding(14.dp))
    }
}

@Composable
private fun MenuRow(icon: ImageVector, title: String, subtitle: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Surface1), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Blue)
            Spacer(Modifier.width(12.dp))
            Column {
                Text(title, color = TextPrimary, fontWeight = FontWeight.Bold)
                Text(subtitle, color = TextSecondary, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun AddToPlaylistDialog(
    playlistNames: List<String>,
    onDismiss: () -> Unit,
    onAdd: (String) -> Unit,
    onCreateAndAdd: (String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Adicionar à playlist") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                playlistNames.forEach { playlist ->
                    OutlinedButton(onClick = { onAdd(playlist) }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Rounded.QueueMusic, null)
                        Spacer(Modifier.width(8.dp))
                        Text(playlist, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                OutlinedTextField(value = name, onValueChange = { name = it }, placeholder = { Text("Nova playlist") }, singleLine = true)
            }
        },
        confirmButton = { TextButton(onClick = { onCreateAndAdd(name) }, enabled = name.isNotBlank()) { Text("Criar e adicionar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
