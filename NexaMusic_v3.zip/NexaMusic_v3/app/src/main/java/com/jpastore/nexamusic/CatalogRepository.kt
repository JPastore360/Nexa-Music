package com.jpastore.nexamusic

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

internal object CatalogRepository {
    private const val SEARCH = "https://itunes.apple.com/search"
    private const val LOOKUP = "https://itunes.apple.com/lookup"

    suspend fun searchSongs(term: String, limit: Int = 30): List<Track> = withContext(Dispatchers.IO) {
        val clean = term.trim()
        if (clean.isBlank()) return@withContext emptyList()
        val encoded = URLEncoder.encode(clean, StandardCharsets.UTF_8.toString())
        val url = "$SEARCH?term=$encoded&country=BR&media=music&entity=song&limit=${limit.coerceIn(1, 50)}"
        parseTracks(request(url))
    }

    suspend fun albumTracks(collectionId: String): List<Track> = withContext(Dispatchers.IO) {
        if (collectionId.isBlank()) return@withContext emptyList()
        val url = "$LOOKUP?id=$collectionId&entity=song&country=BR"
        parseTracks(request(url))
            .filter { it.collectionId == collectionId }
            .sortedBy { it.trackNumber }
    }

    suspend fun homeTracks(): List<Track> = withContext(Dispatchers.IO) {
        val terms = listOf("sertanejo", "pop brasil", "rock", "mpb")
        val combined = mutableListOf<Track>()
        for (term in terms) {
            runCatching { searchSongs(term, 12) }.getOrDefault(emptyList()).let(combined::addAll)
        }
        combined.distinctBy { it.id }.take(40)
    }

    fun albumsFrom(tracks: List<Track>): List<AlbumSummary> = tracks
        .filter { it.collectionId.isNotBlank() && it.album.isNotBlank() }
        .distinctBy { it.collectionId }
        .map { track ->
            AlbumSummary(
                collectionId = track.collectionId,
                title = track.album,
                artist = track.artist,
                artworkUrl = track.artworkUrl,
                genre = track.genre,
                seedTrack = track
            )
        }

    private fun request(urlString: String): String {
        val connection = (URL(urlString).openConnection() as HttpURLConnection).apply {
            connectTimeout = 12_000
            readTimeout = 15_000
            requestMethod = "GET"
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "NexaMusic/3.0 Android")
        }
        return try {
            val code = connection.responseCode
            if (code !in 200..299) error("Catálogo indisponível ($code)")
            connection.inputStream.bufferedReader().use { it.readText() }
        } finally {
            connection.disconnect()
        }
    }

    private fun parseTracks(json: String): List<Track> {
        val array = JSONObject(json).optJSONArray("results") ?: return emptyList()
        val result = mutableListOf<Track>()
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            if (item.optString("wrapperType") != "track") continue
            val preview = item.optString("previewUrl").replace("http://", "https://")
            if (preview.isBlank()) continue
            val id = item.optLong("trackId", -1L)
            if (id <= 0L) continue
            val artwork = upgradeArtwork(item.optString("artworkUrl100").replace("http://", "https://"))
            result += Track(
                id = id.toString(),
                title = item.optString("trackName", "Música"),
                artist = item.optString("artistName", "Artista"),
                album = item.optString("collectionName", "Álbum"),
                previewUrl = preview,
                artworkUrl = artwork,
                genre = item.optString("primaryGenreName", "Música"),
                collectionId = item.optLong("collectionId", 0L).takeIf { it > 0 }?.toString().orEmpty(),
                durationMs = item.optLong("trackTimeMillis", 0L),
                trackNumber = item.optInt("trackNumber", 0)
            )
        }
        return result.distinctBy { it.id }
    }

    private fun upgradeArtwork(url: String): String = url
        .replace("100x100bb", "600x600bb")
        .replace("100x100-75", "600x600-75")
}
