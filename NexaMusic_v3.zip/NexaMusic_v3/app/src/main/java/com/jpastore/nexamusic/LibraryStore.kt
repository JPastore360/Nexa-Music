package com.jpastore.nexamusic

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

internal class LibraryStore(context: Context) {
    private val prefs = context.getSharedPreferences("nexa_music_library_v3", Context.MODE_PRIVATE)

    fun getLiked(): List<Track> = readTrackArray(KEY_LIKED)

    fun toggleLiked(track: Track): List<Track> {
        val current = getLiked().toMutableList()
        val index = current.indexOfFirst { it.id == track.id }
        if (index >= 0) current.removeAt(index) else current.add(0, track)
        writeTrackArray(KEY_LIKED, current)
        return current
    }

    fun getHistory(): List<Track> = readTrackArray(KEY_HISTORY)

    fun addHistory(track: Track): List<Track> {
        val updated = (listOf(track) + getHistory().filterNot { it.id == track.id }).take(MAX_HISTORY)
        writeTrackArray(KEY_HISTORY, updated)
        return updated
    }

    fun getPlaylists(): Map<String, List<Track>> {
        val raw = prefs.getString(KEY_PLAYLISTS, null) ?: return emptyMap()
        return runCatching {
            val root = JSONObject(raw)
            buildMap {
                val keys = root.keys()
                while (keys.hasNext()) {
                    val name = keys.next()
                    val arr = root.optJSONArray(name) ?: JSONArray()
                    put(name, parseTrackArray(arr))
                }
            }
        }.getOrDefault(emptyMap())
    }

    fun createPlaylist(name: String): Map<String, List<Track>> {
        val clean = name.trim().take(40)
        if (clean.isBlank()) return getPlaylists()
        val updated = getPlaylists().toMutableMap()
        if (!updated.containsKey(clean)) updated[clean] = emptyList()
        savePlaylists(updated)
        return updated
    }

    fun addToPlaylist(name: String, track: Track): Map<String, List<Track>> {
        val updated = getPlaylists().toMutableMap()
        val items = updated[name].orEmpty()
        updated[name] = (items + track).distinctBy { it.id }
        savePlaylists(updated)
        return updated
    }

    fun removeFromPlaylist(name: String, track: Track): Map<String, List<Track>> {
        val updated = getPlaylists().toMutableMap()
        updated[name] = updated[name].orEmpty().filterNot { it.id == track.id }
        savePlaylists(updated)
        return updated
    }

    fun deletePlaylist(name: String): Map<String, List<Track>> {
        val updated = getPlaylists().toMutableMap()
        updated.remove(name)
        savePlaylists(updated)
        return updated
    }

    private fun readTrackArray(key: String): List<Track> {
        val raw = prefs.getString(key, null) ?: return emptyList()
        return runCatching { parseTrackArray(JSONArray(raw)) }.getOrDefault(emptyList())
    }

    private fun writeTrackArray(key: String, tracks: List<Track>) {
        val array = JSONArray()
        tracks.forEach { array.put(it.toJson()) }
        prefs.edit().putString(key, array.toString()).apply()
    }

    private fun parseTrackArray(array: JSONArray): List<Track> = buildList {
        for (i in 0 until array.length()) {
            array.optJSONObject(i)?.let(::trackFromJson)?.let(::add)
        }
    }.distinctBy { it.id }

    private fun savePlaylists(playlists: Map<String, List<Track>>) {
        val root = JSONObject()
        playlists.forEach { (name, tracks) ->
            val array = JSONArray()
            tracks.forEach { array.put(it.toJson()) }
            root.put(name, array)
        }
        prefs.edit().putString(KEY_PLAYLISTS, root.toString()).apply()
    }

    companion object {
        private const val KEY_LIKED = "liked"
        private const val KEY_HISTORY = "history"
        private const val KEY_PLAYLISTS = "playlists"
        private const val MAX_HISTORY = 40
    }
}
