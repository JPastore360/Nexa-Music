package com.jpastore.nexamusic

import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import org.json.JSONObject

internal data class Track(
    val id: String,
    val title: String,
    val artist: String,
    val album: String,
    val previewUrl: String,
    val artworkUrl: String,
    val genre: String,
    val collectionId: String,
    val durationMs: Long = 0L,
    val trackNumber: Int = 0
)

internal data class AlbumSummary(
    val collectionId: String,
    val title: String,
    val artist: String,
    val artworkUrl: String,
    val genre: String,
    val seedTrack: Track
)

internal fun Track.toMediaItem(): MediaItem {
    val metadataBuilder = MediaMetadata.Builder()
        .setTitle(title)
        .setArtist(artist)
        .setAlbumTitle(album)

    if (artworkUrl.isNotBlank()) {
        metadataBuilder.setArtworkUri(Uri.parse(artworkUrl))
    }

    return MediaItem.Builder()
        .setMediaId(id)
        .setUri(previewUrl)
        .setMediaMetadata(metadataBuilder.build())
        .build()
}

internal fun Track.toJson(): JSONObject = JSONObject().apply {
    put("id", id)
    put("title", title)
    put("artist", artist)
    put("album", album)
    put("previewUrl", previewUrl)
    put("artworkUrl", artworkUrl)
    put("genre", genre)
    put("collectionId", collectionId)
    put("durationMs", durationMs)
    put("trackNumber", trackNumber)
}

internal fun trackFromJson(json: JSONObject): Track? {
    val id = json.optString("id")
    val previewUrl = json.optString("previewUrl")
    if (id.isBlank() || previewUrl.isBlank()) return null

    return Track(
        id = id,
        title = json.optString("title", "Música"),
        artist = json.optString("artist", "Artista"),
        album = json.optString("album", "Álbum"),
        previewUrl = previewUrl,
        artworkUrl = json.optString("artworkUrl", ""),
        genre = json.optString("genre", "Música"),
        collectionId = json.optString("collectionId", ""),
        durationMs = json.optLong("durationMs", 0L),
        trackNumber = json.optInt("trackNumber", 0)
    )
}
