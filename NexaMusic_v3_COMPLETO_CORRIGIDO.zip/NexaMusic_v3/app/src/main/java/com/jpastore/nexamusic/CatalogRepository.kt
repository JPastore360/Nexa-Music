package com.jpastore.nexamusic

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

internal object CatalogRepository {
    private const val SEARCH_URL = "https://itunes.apple.com/search"
    private const val LOOKUP_URL = "https://itunes.apple.com/lookup"

    suspend fun searchSongs(term: String, limit: Int = 30): List<Track> = withContext(Dispatchers.IO) {
        val clean = term.trim()
        if (clean.length < 2) return@withContext emptyList()

        val encoded = URLEncoder.encode(clean, "UTF-8")
        val url = "$SEARCH_URL?term=$encoded&country=BR&media=music&entity=song&limit=${limit.coerceIn(1, 50)}"
        parseTracks(request(url))
    }

    suspend fun homeTracks(): List<Track> = withContext(Dispatchers.IO) {
        val result = mutableListOf<Track>()
        val terms = listOf("sertanejo brasil", "pop brasil", "rock hits", "mpb brasil")

        for (term in terms) {
            try {
                result.addAll(searchSongs(term, 10))
            } catch (_: Exception) {
                // continua com as demais categorias
            }
        }

        result.distinctBy { it.id }.take(36)
    }

    suspend fun albumTracks(collectionId: String): List<Track> = withContext(Dispatchers.IO) {
        if (collectionId.isBlank()) return@withContext emptyList()
        val url = "$LOOKUP_URL?id=$collectionId&entity=song&country=BR"
        parseTracks(request(url))
            .filter { it.collectionId == collectionId }
            .sortedBy { it.trackNumber }
    }

    fun albumsFrom(tracks: List<Track>): List<AlbumSummary> {
        val seen = mutableSetOf<String>()
        val albums = mutableListOf<AlbumSummary>()

        for (track in tracks) {
            if (track.collectionId.isBlank() || track.album.isBlank()) continue
            if (!seen.add(track.collectionId)) continue

            albums += AlbumSummary(
                collectionId = track.collectionId,
                title = track.album,
                artist = track.artist,
                artworkUrl = track.artworkUrl,
                genre = track.genre,
                seedTrack = track
            )
        }
        return albums
    }

    private fun request(urlString: String): String {
        val connection = URL(urlString).openConnection() as HttpURLConnection
        connection.connectTimeout = 12_000
        connection.readTimeout = 15_000
        connection.requestMethod = "GET"
        connection.setRequestProperty("Accept", "application/json")
        connection.setRequestProperty("User-Agent", "NexaMusic/3.1 Android")

        return try {
            val status = connection.responseCode
            if (status !in 200..299) throw IllegalStateException("HTTP $status")
            connection.inputStream.bufferedReader().use { it.readText() }
        } finally {
            connection.disconnect()
        }
    }

    private fun parseTracks(json: String): List<Track> {
        val root = JSONObject(json)
        val array = root.optJSONArray("results") ?: return emptyList()
        val tracks = mutableListOf<Track>()

        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            if (item.optString("wrapperType") != "track") continue

            val trackId = item.optLong("trackId", -1L)
            val preview = item.optString("previewUrl", "").replace("http://", "https://")
            if (trackId <= 0L || preview.isBlank()) continue

            val collectionId = item.optLong("collectionId", 0L)
            val artwork = item.optString("artworkUrl100", "")
                .replace("http://", "https://")
                .replace("100x100bb", "600x600bb")

            tracks += Track(
                id = trackId.toString(),
                title = item.optString("trackName", "Música"),
                artist = item.optString("artistName", "Artista"),
                album = item.optString("collectionName", "Álbum"),
                previewUrl = preview,
                artworkUrl = artwork,
                genre = item.optString("primaryGenreName", "Música"),
                collectionId = if (collectionId > 0L) collectionId.toString() else "",
                durationMs = item.optLong("trackTimeMillis", 0L),
                trackNumber = item.optInt("trackNumber", 0)
            )
        }

        return tracks.distinctBy { it.id }
    }
}
