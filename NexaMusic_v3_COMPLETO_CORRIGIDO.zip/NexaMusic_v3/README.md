# Nexa Music v3.1

Versão corrigida construída a partir da base v2 que já compilou no GitHub Actions.

## Principais recursos
- Home com álbuns e capas carregados do catálogo online
- Busca por música, artista e álbum
- Tela de álbum com faixas
- Reprodução com Media3 / ExoPlayer
- Reprodução em segundo plano e controles do sistema
- Mini-player e player expandido
- Favoritos, histórico e playlists locais
- Nexa AI Beta para criar seleções a partir de pedidos em linguagem natural
- Créditos no final do Perfil

## Observação do catálogo
A reprodução online desta etapa utiliza as prévias disponibilizadas pelo catálogo consultado. Streaming integral exige integração com um provedor/licenciamento apropriado.

Criado por J. Pastore
