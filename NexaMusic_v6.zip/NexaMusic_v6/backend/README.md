# Backend comercial Nexa Music

A partir da v6, o Android aceita a variável `MUSIC_BACKEND_URL`.

Este backend será a ponte segura para Tuned Global, MassiveMusic ou outro provedor comercial. Credenciais privadas do provedor NÃO devem ser compiladas no APK.

## Contrato esperado pelo Android

### GET /v1/search?query=...&limit=40
### GET /v1/home?limit=36
### GET /v1/albums/{albumId}/tracks?limit=100

Resposta normalizada:

```json
{
  "tracks": [
    {
      "id": "provider-track-id",
      "title": "Track",
      "artist": "Artist",
      "album": "Album",
      "albumId": "provider-album-id",
      "streamUrl": "https://signed-or-authorized-stream-url",
      "artworkUrl": "https://...",
      "genre": "Pop",
      "durationMs": 210000,
      "trackNumber": 1,
      "provider": "Tuned Global"
    }
  ]
}
```

Se `MUSIC_BACKEND_URL` não for configurada, a Nexa Music ignora essa camada e mantém o catálogo gratuito atual.

## Segurança

- Chaves privadas e segredos do provedor ficam apenas no backend.
- O backend pode ser hospedado em Cloudflare Workers, Supabase Edge Functions ou outro servidor.
- URLs de streaming temporárias/assinadas podem ser repassadas ao player quando o contrato permitir.
- Implementar geolocalização/entitlement/reporting conforme o contrato do provedor.
