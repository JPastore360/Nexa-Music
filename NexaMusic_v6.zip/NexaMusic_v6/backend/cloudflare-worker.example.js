/**
 * Nexa Music commercial catalog bridge — scaffold.
 * Configure provider credentials as encrypted Worker secrets.
 * This file intentionally does not contain provider-specific secrets or undocumented endpoints.
 */
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === "/health") {
      return json({ ok: true, service: "nexa-music-catalog-bridge" });
    }

    if (!env.CATALOG_PROVIDER) {
      return json({ error: "Commercial provider not configured" }, 503);
    }

    // Implement after receiving the official commercial credentials/contract.
    // Normalize provider responses to the schema documented in backend/README.md.
    return json({ error: "Provider adapter pending commercial credentials" }, 501);
  }
};

function json(value, status = 200) {
  return new Response(JSON.stringify(value), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store"
    }
  });
}
