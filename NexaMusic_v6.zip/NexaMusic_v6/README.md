# Nexa Music v6

Versão 6.0.0.

## Principais mudanças

- **Criar conta agora funciona mesmo sem backend pago.**
- Cadastro por e-mail + senha ou telefone + senha.
- Telefone + senha funciona localmente sem SMS e sem cobrança.
- Senhas locais não são gravadas em texto puro: PBKDF2 + salt aleatório no armazenamento privado do app.
- Login local funciona novamente depois de sair da conta.
- Quando Supabase estiver configurado, o app tenta autenticação em nuvem e mantém a conta local como contingência.
- Perfil diferencia Visitante, Conta Nexa local e Conta na nuvem.
- Mantidos player Media3, tela bloqueada, segundo plano, favoritos, histórico, playlists, Nexa AI e catálogo híbrido.
- Preparada uma **ponte para catálogo comercial** via `MUSIC_BACKEND_URL` sem expor credenciais no APK.
- Mantida a assinatura estável introduzida na v5 para permitir atualizações por cima.

## Atualização por cima

O `applicationId` continua:

`com.jpastore.nexamusic`

A v6 reutiliza exatamente o mesmo arquivo `app/nexa-test.keystore` e as mesmas credenciais de assinatura da v5.

- Se a versão instalada for **v5 assinada com esta chave**, a v6 pode ser instalada diretamente por cima e os dados permanecem.
- Se a versão instalada for **v4 ou anterior**, ela foi gerada com a chave debug efêmera do GitHub Actions. Não é tecnicamente possível reproduzir aquela assinatura; será necessário desinstalar uma única vez e instalar a v6. Da v5/v6 em diante, manter a mesma chave evita repetir isso.

## Contas

### Sem Supabase

O cadastro e login funcionam localmente no aparelho. A conta permanece enquanto o app não for desinstalado/limpo.

### Com Supabase

Secrets opcionais no GitHub Actions:

- `SUPABASE_URL`
- `SUPABASE_ANON_KEY`

Execute também `supabase_schema.sql` para sincronizar a biblioteca.

## Catálogo

Secrets opcionais:

- `JAMENDO_CLIENT_ID`
- `MUSIC_BACKEND_URL`

`MUSIC_BACKEND_URL` é a ponte futura para um provedor comercial licenciado. Consulte `PREMIUM_CATALOG_ROADMAP.md` e `backend/README.md`.

Criado por J. Pastore • Powered by Nexa AI
