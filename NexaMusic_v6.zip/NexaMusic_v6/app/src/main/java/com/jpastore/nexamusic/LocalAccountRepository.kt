package com.jpastore.nexamusic

import android.content.Context
import android.util.Base64
import android.util.Patterns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * Conta local do Nexa Music.
 *
 * Permite que Criar conta / Entrar funcionem mesmo antes de configurar um backend.
 * A senha nunca é gravada em texto puro: apenas salt aleatório + hash PBKDF2.
 * O cadastro fica no armazenamento privado do aplicativo e é preservado ao instalar
 * uma nova versão por cima com o mesmo applicationId e a mesma assinatura.
 */
internal class LocalAccountRepository(context: Context) {
    private val prefs = context.getSharedPreferences("nexa_music_local_accounts_v6", Context.MODE_PRIVATE)

    suspend fun signUp(identifier: String, password: String, usePhone: Boolean): AuthResponse =
        withContext(Dispatchers.Default) {
            val normalized = normalize(identifier, usePhone)
            val validation = validate(normalized, password, usePhone)
            if (validation != null) return@withContext AuthResponse(message = validation)

            val key = accountKey(normalized)
            val prefKey = "account_$key"
            if (prefs.contains(prefKey)) {
                return@withContext AuthResponse(message = "Já existe uma conta com esses dados neste aparelho.")
            }

            val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
            val hash = derive(password, salt)
            val label = identifier.trim()
            val userId = "local:${key.take(24)}"

            val json = JSONObject().apply {
                put("userId", userId)
                put("label", label)
                put("normalized", normalized)
                put("phone", usePhone)
                put("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
                put("hash", Base64.encodeToString(hash, Base64.NO_WRAP))
            }
            prefs.edit().putString(prefKey, json.toString()).apply()

            AuthResponse(
                session = AuthSession(userId, label, "", "", false),
                message = "Conta criada neste aparelho."
            )
        }

    suspend fun signIn(identifier: String, password: String, usePhone: Boolean): AuthResponse =
        withContext(Dispatchers.Default) {
            val normalized = normalize(identifier, usePhone)
            if (normalized.isBlank() || password.isBlank()) {
                return@withContext AuthResponse(message = "Preencha seu acesso e a senha.")
            }

            val prefKey = "account_${accountKey(normalized)}"
            val raw = prefs.getString(prefKey, null)
                ?: return@withContext AuthResponse(message = "Conta não encontrada neste aparelho.")

            return@withContext try {
                val json = JSONObject(raw)
                val salt = Base64.decode(json.getString("salt"), Base64.NO_WRAP)
                val expected = Base64.decode(json.getString("hash"), Base64.NO_WRAP)
                val actual = derive(password, salt)
                if (!MessageDigest.isEqual(expected, actual)) {
                    AuthResponse(message = "E-mail/telefone ou senha incorretos.")
                } else {
                    AuthResponse(
                        session = AuthSession(
                            userId = json.getString("userId"),
                            label = json.optString("label").ifBlank { identifier.trim() },
                            accessToken = "",
                            refreshToken = "",
                            isGuest = false
                        ),
                        message = "Conectado"
                    )
                }
            } catch (_: Exception) {
                AuthResponse(message = "Não foi possível abrir esta conta local.")
            }
        }

    private fun normalize(identifier: String, usePhone: Boolean): String {
        val trimmed = identifier.trim()
        return if (usePhone) {
            val hasPlus = trimmed.startsWith("+")
            val digits = trimmed.filter(Char::isDigit)
            if (hasPlus) "+$digits" else digits
        } else {
            trimmed.lowercase()
        }
    }

    private fun validate(identifier: String, password: String, usePhone: Boolean): String? {
        if (usePhone) {
            val digits = identifier.filter(Char::isDigit)
            if (digits.length !in 10..15) return "Digite um telefone válido, de preferência com DDI (+55...)."
        } else if (!Patterns.EMAIL_ADDRESS.matcher(identifier).matches()) {
            return "Digite um e-mail válido."
        }
        if (password.length < 8) return "A senha precisa ter pelo menos 8 caracteres."
        return null
    }

    private fun accountKey(normalized: String): String =
        MessageDigest.getInstance("SHA-256")
            .digest(normalized.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it.toInt() and 0xff) }

    private fun derive(password: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(password.toCharArray(), salt, 120_000, 256)
        return try {
            SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        } finally {
            spec.clearPassword()
        }
    }
}
