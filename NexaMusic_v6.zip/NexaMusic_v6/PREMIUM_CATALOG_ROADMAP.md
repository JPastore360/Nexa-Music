# Nexa Music — roteiro para catálogo comercial

Atualizado em 23/09/2026.

## Objetivo

Manter a interface, a Nexa AI e o player Android próprios, mas trocar/expandir a camada de catálogo por um provedor B2B licenciado capaz de oferecer busca ampla e reprodução integral.

## 1. Tuned Global

- Site: https://www.tunedglobal.com/
- Contato: https://www.tunedglobal.com/contact
- E-mail geral publicado: info@tunedglobal.com
- Plataforma B2B para streaming com catálogo global, busca, metadata, playlists, autenticação, assinaturas, reporting e reprodução integral conforme os direitos contratados.
- A empresa informa catálogo acima de 150 milhões de faixas na plataforma atual e mais de 500 APIs para projetos de streaming.
- A documentação e o site deixam claro que a disponibilidade efetiva depende dos acordos/licenças aplicáveis ao serviço e território.
- Não há tabela pública de preços simples; é necessário orçamento comercial.
- A empresa diz atender projetos em dezenas de países e também fala com empresas que estão iniciando um serviço, mas não publica um faturamento mínimo ou tamanho mínimo de cliente.

### Perguntas a enviar

1. Vocês aceitam um projeto Android em fase beta/startup com lançamento inicial no Brasil?
2. Qual é o menor compromisso mensal para API + streaming on-demand?
3. Há taxa inicial de setup/onboarding?
4. Quais direitos/licenças para Brasil podem ser facilitados por vocês?
5. Qual parte de majors/indies pode ser disponibilizada para um novo DSP brasileiro?
6. O pacote inclui search, artwork, albums, playlists, recommendations, full-length streaming, offline e reporting?
7. Existe sandbox ou credencial de teste antes do contrato final?
8. Quais requisitos de número mínimo de usuários ou projeção de streams?

## 2. MassiveMusic / 7digital platform

- Site: https://massivemusic.com/services/platform-music-delivery-services/api-music-delivery
- Documentação: https://docs.massivemusic.com/
- Contato Américas: americas@massivemusic.com
- A plataforma informa conexão com detentores de direitos representando mais de 150 milhões de faixas.
- Suporta serviços de streaming, inclusive subscription streaming, entrega de áudio, catálogo, metadata, reporting e disponibilidade territorial.
- O catálogo liberado para cada cliente depende dos acordos de licenciamento desse cliente.
- A MassiveMusic informa operar também em LATAM.
- A FAQ informa modelos de subscription, SLA, retainer e enterprise dependendo da necessidade; não há preço público fechado para esse produto.
- Para streaming comercial, a documentação exige reporting e controles de disponibilidade territorial; credenciais sensíveis devem permanecer em servidor seguro, nunca dentro do APK.

### Perguntas a enviar

1. Vocês atendem uma startup/DSP Android em beta com mercado inicial no Brasil?
2. Qual o custo mínimo mensal e eventual setup para on-demand full-length streaming?
3. O contrato pode começar com poucos usuários e escalar conforme os streams?
4. Vocês auxiliam na obtenção/configuração dos direitos para Brasil ou exigem contratos diretos prévios com os rightsholders?
5. Há sandbox com catálogo de teste?
6. Quais serviços entram no mínimo comercial: catálogo, search, audio delivery, artwork, user/subscription API e reporting?
7. Quais são os requisitos de DDEX/DPID e prazo de aprovação do app antes do lançamento?

## Arquitetura escolhida para a Nexa Music

Não colocar credenciais Tuned Global/MassiveMusic dentro do APK.

Fluxo:

Nexa Music Android → Backend Nexa → Provedor comercial → URL de stream autorizada → Media3

O APK v6 já aceita uma URL de backend em `MUSIC_BACKEND_URL`. Se estiver vazia, o app continua usando as fontes gratuitas atuais. Quando houver contrato e credenciais, o backend normaliza o provedor comercial sem exigir refazer a interface Android.

## Mensagem pronta — inglês

Subject: Music streaming API for an early-stage Android DSP in Brazil

Hello,

I am building Nexa Music, an Android music streaming application currently in beta. We have our own front-end, player, background playback, user accounts, playlists, favourites and AI-assisted discovery. We are evaluating a licensed B2B catalogue/API for an initial launch in Brazil.

Our main requirement is on-demand full-length streaming with broad commercial catalogue coverage, search, artists/albums, artwork, playlists and usage/rightsholder reporting. The project will start with a small user base and should scale as adoption grows.

Could you please advise:
- whether you support an early-stage/startup service launching in Brazil;
- minimum monthly commitment and any setup/onboarding fees;
- sandbox/test access availability;
- catalogue/licensing options for Brazil;
- minimum user/stream commitments, if any;
- what API and reporting services are included in the entry commercial package.

Thank you,
J. Pastore
Nexa Music

## Próximo passo quando chegar uma proposta

Comparar somente fatos do contrato: mensalidade mínima, setup, custo por stream/usuário, território Brasil, catálogo efetivamente licenciado, direitos de on-demand/offline, limites técnicos, prazo de implantação, exigência de reporting e prazo mínimo de contrato.
